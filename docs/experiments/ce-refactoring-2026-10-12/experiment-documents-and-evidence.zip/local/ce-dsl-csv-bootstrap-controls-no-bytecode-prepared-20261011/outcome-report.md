# -B control outcome — two retained QA failures, STOP

Exact f0acc9c0 packet launched controls once. Native pytest exit1; child/PGID3163 exit2; launcher exit2. All six nodes and18 phases ran: two call phases failed, other16 phases passed. Retained37 scalar observer-error rows parse exactly; warnings=[], captured stderr empty, guard bootstrap_errors=[], forbidden=[], CE imports=[] and spawns=[]. Native hooks/profiles/FD restore true; no acceptance or native-owner admission follows.

First failure: original native run→_handle_tasks→handler-return→run-return quartet with exact ident/nativeID/object correspondence and timed incomplete versus completed join were observed. The actual first _bootstrap_inner callback is its return AFTER run, making the control's audit→bootstrap-first→run assertion false. This is the control's assumption, not a missing event or CE defect. Observe the real first inherited-profiler event across pinned native frames; never invent a retrospective bootstrap call.

Second failure: real pre-body wrong-code frame with a new but equal CodeType identity produced one unexpected bootstrap row. The new observer's CodeType-keyed dictionary membership uses equality, not identity. Existing delivery identity checks remain separate. This is a QA observer exact-identity bug, not CE product behavior.

-B reached collection without the prior outside-child pytest_cov __pycache__ refusal; forbidden rows are empty. Failure STOP prevented timeout profile: no timeout directory/child, no retry or fix. Therefore timeout-retention proof remains UNVERIFIED. Both cleanup receipts show group gone/leader reaped/no signals or unexpected members; PID independently absent. All38 frozen pins, previous failure and held timeout remain exact.

LOCAL VERIFIED: six tests18phases/37scalars, two actual failures, raw native events and join observations, native hook/profile/FD restoration, frozen pins and terminal cleanup. CI-ONLY VERIFICATION: none.

Independent Astra final interpretation requested through Root. Original Pool cause/current parity remain UNKNOWN; no CE issue, release or native-owner claim.
