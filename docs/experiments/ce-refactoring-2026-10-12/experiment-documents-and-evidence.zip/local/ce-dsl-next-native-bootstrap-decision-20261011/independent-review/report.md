# PASS for preparation only — narrow bootstrap observation

The proposal identifies the earliest evidenced gap. Exact pinned native source signals Thread._started before inherited-profile installation and before protected run; the old task thread has IDs without run/handler events or a matching 45-second stack. Those absences cannot establish death, failed installation, or a payload cause. The unidentified join thread also remains UNKNOWN. The passing empty-handler control does not reproduce native Pool/CE ordering.

Recommend one small extension inside the existing passive observation path: exact native start call/return identity, the profile-install audit boundary, first observed inherited-profile event in the pinned bootstrap frame, and exact join caller/joined-thread identity. Reuse code/globals/source pins, role recognition, existing receipt writer and unchanged effect/spawn/cleanup policies. No new Pool harness or guard framework is justified.

Three details must remain explicit in implementation admission:
- A profile installed midway through _bootstrap_inner cannot retrospectively observe its call. Record the actual first event and prove its identity on real frames; do not prescribe an unobserved event kind or infer successful installation from an audit event alone. Read expected callback identity from the pinned native frame/global context, not assumed audit arguments.
- Cache scalar target identity at start, before native run can delete _target. Join must identify both the executing caller and joined object, using retained identity when available; missing correspondence stays UNKNOWN. A start return or a timed join return is not proof of handler entry or completion.
- Bound observations to exact native frames and scalar identities. Preserve unmatched/error evidence without repr, arbitrary property access, payload iteration, hook replacement or effect waiver. New observations can themselves alter timing or fail, so their control must distinguish recorder failure from native behavior.

This accepts the scope for preparation and exact-code/control review only. Establish the small observer extension on separately admitted CE-free real frames before any owner proposal. It grants no native control, original owner retry, current counterpart, payload experiment or automatic execution. Root GO remains separate and tied to exact frozen bytes and unchanged guards. No cause or runtime parity conclusion follows.

LOCAL VERIFIED: proposal hash 001fea2a; ten unique input paths and seven native/observer snippet hashes; read-only source and retained receipt review. CI-ONLY VERIFICATION: none.

Skipped all native execution, packet/source changes and ledger writes. Risk: original timeout cause and full CE multiprocessing parity remain UNKNOWN.
