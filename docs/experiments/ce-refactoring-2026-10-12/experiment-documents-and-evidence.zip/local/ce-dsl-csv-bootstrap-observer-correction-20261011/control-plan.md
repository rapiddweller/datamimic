# Corrections and control preparation — no execution

Corrections are confined to the three Astra findings. First candidate preserved. Native installation matches direct pinned _bootstrap_inner line1042, optionally through the exact existing observer audit-lambda code/global identity, never a run/target ancestor. Audit evidence remains preinstallation only. Every native start resets stale first-event/target state before assigning its new scalar start ticket. Atomic C itertools.count reservations enforce 64 observations and16 starts before any hashing/I/O; limit overflow invalidates, not silently truncates. First16 scalar failures emit through existing sys.stderr capture and propagate; verify rejects retained errors. A stderr write failure propagates and invalidates; its own persistence is UNKNOWN if the existing stderr transport fails. No new transport or lock.

Prepared minimum control cases for separately reviewed existing CE-free context (NOT RUN):
1. Actual native start→direct install audit→actual first profiler event→run→completed join; assert observed event kind without inventing call. Target retained after native _target deletion.
2. Native timed join with live target: completion_observed false, timeout retained; later completed join true. Caller and joined-object identities distinct.
3. Target calls sys.setprofile: no native-install audit row, even with bootstrap ancestor. Exact existing audit-lambda and direct guard-audit installation both accepted only at pinned1042.
4. Repeat real start bookkeeping using an already marked scalar object ID: marker discarded/target replaced; cache refusal removes stale target and invalidates. This is bookkeeping proof, not actual OS object-ID reuse proof.
5. Reuse unchanged inherited exact-type/code/globals/source negative controls. Pin drift and callback mismatch must produce scalar stderr evidence and propagate; no PASS.
6. Forced existing receipt writer failure: retained scalar row/error, captured stderr, propagation and verify rejection. Saturate row/start bounds; concurrent reservation boundary tickets unique and never more than64 admitted records. Error16 bound preserves first failure and continues rejection.

Prepared script: test_bootstrap_controls.py. The script is not executed. Existing once-only official-pytest FD-capture launcher must supply this exact test file and reviewed candidate origins before separate Root GO; it remains the existing execution/terminal transport, not a new launcher. Existing __new__ fixture requires receipt={} before delivery_setup; no existing control result proves new branches. No control/native/owner/Pool execution, packet edits or ledger promotion.

LOCAL VERIFIED: AST syntax only. CI-ONLY VERIFICATION: none.

UNKNOWN: runtime correspondence, actual first event, interleaving, terminal persistence when stderr itself fails, original timeout and current runtime parity. Owner/native diagnostic rerun remains held.
