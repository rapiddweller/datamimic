"""Prepared CE-free controls; execution requires separate exact-code admission."""
from pathlib import Path
import importlib.util
import itertools
import json
import os
import queue
import sys
import threading
import types

import pytest

B = Path(__file__).resolve().parent
N = Path('/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011')
M = json.loads((N / 'manifest.json').read_text())
R = B / 'runs/original/child'
sys.path[:0] = [str(N), str(N / 'recorder')]
os.environ['STEP193_SOURCE'] = M['sources']['original']['root']
os.environ['STEP193_EVENTS'] = str(R / 'events')
spec = importlib.util.spec_from_file_location('bootstrap_candidate', B / 'mp_guard.py')
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)


@pytest.fixture(scope='module')
def native_guard():
    assert not R.exists(), 'once-only control output already exists'
    R.mkdir(parents=True)
    receipt = {'audit': {'opens': [], 'mutations': [], 'forbidden': []},
               'instances': [], 'executions': [], 'captures': []}
    guard = G.ParentGuard(M, M['sources']['original'], R, receipt)
    sys.addaudithook(guard.audit)
    yield guard
    assert not guard.bootstrap_errors
    assert not receipt['audit']['forbidden']
    assert not guard.spawns
    assert not any(n == 'datamimic_ce' or n.startswith(('datamimic_ce.', 'tests_ce.')) for n in sys.modules)
    (R / 'control-terminal.json').write_text(json.dumps({'status': 'PASS_CONTROLS_ONLY',
        'bootstrap_rows': guard.bootstrap_rows, 'bootstrap_errors': guard.bootstrap_errors,
        'spawns': guard.spawns, 'forbidden': receipt['audit']['forbidden']}, indent=2) + '\n')


def test_real_native_first_event_timed_and_completed_join(native_guard):
    guard = native_guard
    tasks, outputs = queue.SimpleQueue(), queue.SimpleQueue()
    thread = threading.Thread(target=G.pool.Pool._handle_tasks,
        args=(tasks, outputs.put, outputs, [], {}), daemon=True)
    # Simulate stale bookkeeping, not an OS object-ID reuse claim.
    guard.bootstrap_first.add(id(thread))
    guard.bootstrap_targets[id(thread)] = {'role': 'stale'}
    before = len(guard.bootstrap_rows)
    previous, inherited = sys.getprofile(), threading.getprofile()
    assert previous is None and inherited is None
    try:
        sys.setprofile(guard.profile)
        threading.setprofile(guard.profile)
        thread.start()
        thread.join(timeout=0)
        assert not vars(thread)['_is_stopped']
        tasks.put(None)
        thread.join(timeout=1)
        assert vars(thread)['_is_stopped']
    finally:
        tasks.put(None)
        sys.setprofile(previous)
        threading.setprofile(inherited)
        thread.join(timeout=1)
    assert not thread.is_alive()
    assert outputs.get_nowait() is None
    rows = [r for r in guard.bootstrap_rows[before:] if r.get('thread_object_id') == id(thread)]
    audits = [r for r in rows if r['actual_event'] == 'audit_sys_setprofile']
    first = [r for r in rows if r.get('first_observed_bootstrap_event')]
    assert len(audits) == len(first) == 1
    assert audits[0]['expected_callback_is_guard'] is True
    assert first[0]['actual_event'] in ('call', 'return', 'c_call', 'c_return', 'c_exception')
    assert first[0]['thread_ident'] == thread.ident
    assert first[0]['thread_native_id'] == thread.native_id
    returns = [r for r in rows if r['function'] == 'join' and r['actual_event'] == 'return']
    assert [(r['timeout'], r['completion_observed']) for r in returns] == [(0, False), (1, True)]
    assert all(r['caller_object_id'] != id(thread) for r in returns)
    assert '_target' not in vars(thread)
    assert all(r['retained_target']['role'] == 'task' for r in returns)
    delivery = [json.loads(line) for line in (R / 'parent-spawn-phases.jsonl').read_text().splitlines()]
    assert any(x['phase'] == 'delivery' and x['row']['function'] == '_handle_tasks' for x in delivery)


def test_target_profile_change_is_not_installation(native_guard):
    guard = native_guard
    called = []
    def target():
        sys.setprofile(guard.profile)
        called.append(True)
    thread = threading.Thread(target=target, daemon=True)
    previous, inherited = sys.getprofile(), threading.getprofile()
    before = len(guard.bootstrap_rows)
    try:
        sys.setprofile(guard.profile)
        threading.setprofile(guard.profile)
        thread.start()
        thread.join(timeout=1)
    finally:
        sys.setprofile(previous)
        threading.setprofile(inherited)
        thread.join(timeout=1)
    assert called == [True] and not thread.is_alive()
    rows = [r for r in guard.bootstrap_rows[before:] if r.get('thread_object_id') == id(thread)]
    assert len([r for r in rows if r['actual_event'] == 'audit_sys_setprofile']) == 1


def isolated_guard():
    guard = G.ParentGuard.__new__(G.ParentGuard)
    guard.receipt = {}
    guard.child = R
    guard.pins = dict(M['spawn']['stdlib_sha256'])
    guard.calls = []
    guard.delivery_setup()
    return guard


class FrameStop(Exception):
    pass


def real_start_frame(thread, fn=None):
    fn = thread.start if fn is None else fn
    code = fn.__func__.__code__ if type(fn) is types.MethodType else fn.__code__
    frames = []
    def stop(frame, event, arg):
        if frame.f_code is code and event == 'call':
            frames.append(frame)
            raise FrameStop()
    previous = sys.getprofile()
    sys.setprofile(stop)
    try:
        fn() if type(fn) is types.MethodType else fn(thread)
    except FrameStop:
        pass
    finally:
        sys.setprofile(previous)
    assert len(frames) == 1
    return frames[0]


def rejected(guard, frame, capfd):
    with pytest.raises((RuntimeError, AssertionError, OSError)):
        guard.bootstrap_observe(frame, 'call')
    stderr = capfd.readouterr().err
    lines = [json.loads(line) for line in stderr.splitlines()]
    assert len(lines) == 1 and 'bootstrap_recorder_error' in lines[0]
    assert guard.bootstrap_errors
    with pytest.raises(AssertionError, match='bootstrap observation invalid'):
        guard.verify()
    # Persist exactly the existing captured scalar stderr in the control result.
    return {'stderr': stderr, 'terminal_acceptance': 'REJECTED', 'errors': guard.bootstrap_errors}


def test_failure_source_writer_and_limits_reject_with_stderr(native_guard, capfd, monkeypatch):
    thread = threading.Thread()
    frame = real_start_frame(thread)
    proofs = []
    guard = isolated_guard()
    path = str(Path(threading.Thread.start.__code__.co_filename).resolve())
    guard.pins[path] = '0' * 64
    proofs.append(rejected(guard, frame, capfd))
    guard = isolated_guard()
    def fail_write(*args):
        raise OSError('control-only receipt writer failure')
    monkeypatch.setattr(guard, 'save_parent', fail_write)
    proofs.append(rejected(guard, frame, capfd))
    guard = isolated_guard()
    guard.bootstrap_tickets = itertools.count(64)
    proofs.append(rejected(guard, frame, capfd))
    guard = isolated_guard()
    guard.bootstrap_targets[id(thread)] = {'role': 'stale'}
    guard.bootstrap_first.add(id(thread))
    guard.bootstrap_start_tickets = itertools.count(16)
    proofs.append(rejected(guard, frame, capfd))
    assert id(thread) not in guard.bootstrap_targets and id(thread) not in guard.bootstrap_first
    guard = isolated_guard()
    for _ in range(17):
        with pytest.raises(RuntimeError):
            guard.bootstrap_fail('CONTROL_ERROR_LIMIT', RuntimeError('control'))
    assert len(guard.bootstrap_errors) == 16
    assert len(capfd.readouterr().err.splitlines()) == 16
    with pytest.raises(AssertionError, match='bootstrap observation invalid'):
        guard.verify()
    (R / 'negative-terminal-stderr.json').write_text(json.dumps(proofs, indent=2) + '\n')


def test_exact_code_globals_and_type_exclusion(native_guard):
    guard = isolated_guard()
    thread = threading.Thread()
    native = threading.Thread.start
    for code, namespace in ((native.__code__.replace(), native.__globals__),
                            (native.__code__, dict(native.__globals__))):
        altered = types.FunctionType(code, namespace)
        frame = real_start_frame(thread, altered)
        guard.bootstrap_observe(frame, 'call')
    assert guard.bootstrap_rows == [] and guard.bootstrap_errors == []
    class Unsupported(threading.Thread):
        def __getattribute__(self, name):
            if name == '__dict__':
                raise AssertionError('unsupported attribute read')
            return super().__getattribute__(name)
    frame = real_start_frame(Unsupported())
    guard.bootstrap_observe(frame, 'call')
    assert guard.bootstrap_rows[-1]['observation'] == 'UNKNOWN_UNSUPPORTED_THREAD_TYPE'


def test_callback_mismatch_and_stderr_transport_failure(native_guard, capfd, monkeypatch):
    guard = isolated_guard()
    thread = threading.Thread()
    frame = real_start_frame(thread, thread._bootstrap_inner)
    # Genuine pre-body frame; this is audit-branch bookkeeping, not installation proof.
    with pytest.raises(RuntimeError, match='callback mismatch'):
        guard.bootstrap_observe(frame, 'audit_sys_setprofile')
    assert 'bootstrap_recorder_error' in capfd.readouterr().err
    with pytest.raises(AssertionError, match='bootstrap observation invalid'):
        guard.verify()
    guard = isolated_guard()
    class BrokenStderr:
        def write(self, text):
            raise OSError('control-only stderr transport failure')
        def flush(self):
            raise OSError('control-only stderr transport failure')
    with monkeypatch.context() as patch:
        patch.setattr(sys, 'stderr', BrokenStderr())
        with pytest.raises(OSError, match='stderr transport failure'):
            guard.bootstrap_fail('CONTROL_STDERR_TRANSPORT_FAILURE', RuntimeError('control'))
    assert len(guard.bootstrap_errors) == 1
    with pytest.raises(AssertionError, match='bootstrap observation invalid'):
        guard.verify()
    (R / 'stderr-transport-failure.json').write_text(json.dumps({'terminal_acceptance': 'REJECTED',
        'stderr_evidence': 'UNKNOWN_TRANSPORT_FAILED', 'errors': guard.bootstrap_errors}) + '\n')


def test_concurrent_record_reservation_limit(native_guard, capfd, monkeypatch):
    guard = isolated_guard()
    class Unsupported(threading.Thread):
        pass
    frame = real_start_frame(Unsupported())
    monkeypatch.setattr(guard, 'save_parent', lambda *args: None)
    barrier = threading.Barrier(2)
    failures = []
    def reserve():
        barrier.wait(timeout=1)
        for _ in range(40):
            try:
                guard.bootstrap_observe(frame, 'call')
            except RuntimeError:
                failures.append(True)
    threads = [threading.Thread(target=reserve, daemon=True) for _ in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=2)
    assert not any(thread.is_alive() for thread in threads)
    assert len(guard.bootstrap_rows) == 64 and len(failures) == 16
    assert len(guard.bootstrap_errors) == 16
    stderr = capfd.readouterr().err
    assert len(stderr.splitlines()) == 16
    with pytest.raises(AssertionError, match='bootstrap observation invalid'):
        guard.verify()
    (R / 'concurrent-limit-stderr.json').write_text(json.dumps({'terminal_acceptance': 'REJECTED',
        'rows': len(guard.bootstrap_rows), 'errors': guard.bootstrap_errors, 'stderr': stderr}) + '\n')
