"""CSV part only: two source-bound pools, four spawn workers and one tracker."""
from pathlib import Path
import json
import multiprocessing.util as util
import multiprocessing.pool as pool
import multiprocessing.queues as queues
import os
import sys
import _posixsubprocess
import time
import faulthandler
import atexit
import threading
import types
import itertools
import multiprocessing.connection as connection
import multiprocessing.reduction as reduction
import observer as O


def frame_pin(frame, pins, name):
    path = Path(frame.f_code.co_filename).resolve()
    assert frame.f_code.co_name == name and str(path) in pins
    assert O.sha(path) == pins[str(path)], 'spawn caller bytes drift'


def spawn_arguments(role, path, args, passfds, python, flags, descriptors):
    exe = os.fsencode(python)
    assert path == exe and type(args) is list
    assert all(type(fd) is int and fd >= 0 for fd in passfds)
    if role == 'tracker':
        r = descriptors['r']
        assert args == [exe, *flags, '-c', 'from multiprocessing.resource_tracker import main;main(%d)' % r]
        assert r in passfds and len(passfds) in (1, 2)
    else:
        assert role == 'worker'
        tracker, reader = descriptors['tracker_fd'], descriptors['child_r']
        code = 'from multiprocessing.spawn import spawn_main; spawn_main(tracker_fd=%r, pipe_handle=%r)' % (tracker, reader)
        assert args == [exe, *flags, '-c', code, '--multiprocessing-fork']
        expected = [tracker, reader, descriptors['child_w'], *descriptors['queue_fds']]
        assert len(descriptors['queue_fds']) == 4 and len(set(expected)) == 7
        assert len(passfds) == 7 and set(passfds) == set(expected)


def native_call(product, chunks, receipt):
    assert product in ('people1', 'people2') and list(chunks) == [(0, 1), (1, 1)]
    assert len(receipt['instances']) == len(receipt['executions']) == 1
    assert receipt['executions'][0]['outcome'] == 'unfinished' and not receipt['captures']


def spawn_budget(spawns, role, product):
    assert role in ('tracker', 'worker')
    assert sum(s['role'] == role for s in spawns) < (1 if role == 'tracker' else 4)
    if role == 'worker':
        assert sum(s['role'] == role and s['product'] == product for s in spawns) < 2


def worker_fork_guard(event, arg):
    if event == 'c_call' and arg is _posixsubprocess.fork_exec:
        raise RuntimeError('worker fork_exec refused')


class ParentGuard:
    def __init__(self, manifest, source, child, receipt):
        import record_process
        self.record = record_process
        self.manifest, self.source, self.child, self.receipt = manifest, source, child, receipt
        self.pins = manifest['spawn']['stdlib_sha256']
        self.worker_file = Path(source['root']) / manifest['spawn']['worker_paths'][child.parts[-2]]
        self.calls, self.spawns, self.active = [], [], {}
        assert record_process.SOURCE == source['root'] and record_process.OUT == str(child / 'events')
        receipt['mp2'] = {'calls': self.calls, 'spawns': self.spawns, 'source_bound': True}
        self.delivery_setup()

    def save_parent(self, phase, row):
        with (self.child / 'parent-spawn-phases.jsonl').open('a') as stream:
            stream.write(json.dumps({'phase': phase, 'monotonic_ns': time.monotonic_ns(),
                'parent_pid': os.getpid(), 'row': dict(row)}) + '\n')

    def delivery_setup(self):
        functions = (pool.Pool.map, pool.Pool._handle_tasks, pool.Pool._guarded_task_generation,
            pool.Pool._get_tasks, connection.Connection.send, reduction.ForkingPickler.dumps.__func__,
            pool.MapResult._set, threading.Thread.run)
        self.delivery_functions = {f.__name__: (f.__code__, f.__globals__) for f in functions}
        hook = next(c for c in threading._make_invoke_excepthook.__code__.co_consts
            if type(c) is types.CodeType and c.co_name == 'invoke_excepthook')
        self.delivery_functions['invoke_excepthook'] = (hook, vars(threading))
        self.delivery_thread_entries = {}
        self.bootstrap_targets, self.bootstrap_first = {}, set()
        self.bootstrap_rows = self.receipt.setdefault('bootstrap_observation', [])
        self.bootstrap_errors = self.receipt.setdefault('bootstrap_recorder_errors', [])
        self.bootstrap_functions = {f.__code__: f.__globals__ for f in
            (threading.Thread.start, threading.Thread.join, threading.Thread._bootstrap_inner)}
        self.bootstrap_tickets = itertools.count()
        self.bootstrap_start_tickets = itertools.count()
        self.bootstrap_error_tickets = itertools.count()
        for code, namespace in self.delivery_functions.values():
            path = str(Path(code.co_filename).resolve())
            assert path in self.pins and O.sha(Path(path)) == self.pins[path]

    def delivery_target(self, thread):
        if type(thread) is not threading.Thread:
            return {'role': 'unknown_unsupported_thread_type', 'target_native': False}
        target = vars(thread).get('_target')
        known = ((pool.Pool._handle_tasks, 'task'), (pool.Pool._handle_results, 'result'))
        for native, role in known:
            if target is native:
                return {'role': role, 'target_native': True, 'target_function': native.__name__,
                    'target_code_id': id(native.__code__)}
        if (type(target) is types.MethodType and target.__func__ is pool.Pool._handle_workers.__func__
                and target.__self__ is pool.Pool):
            return {'role': 'worker', 'target_native': True,
                'target_function': '_handle_workers', 'target_code_id': id(target.__func__.__code__)}
        if (type(target) is types.MethodType and target.__func__ is threading.Thread.join
                and type(target.__self__) is threading.Thread):
            return {'role': 'unbound_to_pool_join', 'target_native': True,
                'target_function': 'join', 'target_code_id': id(threading.Thread.join.__code__),
                'joined_thread_object_id': id(target.__self__)}
        return {'role': 'unknown', 'target_native': False}

    def delivery(self, frame, event, arg):
        if event not in ('call', 'return') or frame.f_code.co_name not in self.delivery_functions:
            return
        code, namespace = self.delivery_functions[frame.f_code.co_name]
        if frame.f_code is not code or frame.f_globals is not namespace:
            return
        frame_pin(frame, self.pins, code.co_name)
        row = {'function': code.co_name, 'event': event,
            'thread_ident': threading.get_ident(), 'thread_native_id': threading.get_native_id(),
            'code_id': id(code), 'source_sha256': self.pins[str(Path(code.co_filename).resolve())]}
        state = frame.f_locals
        if code is pool.Pool.map.__code__ and event == 'call':
            native_pool = state['self']
            if type(native_pool) is not pool.Pool:
                row['observation'] = 'UNKNOWN_UNSUPPORTED_POOL_TYPE'
                self.save_parent('delivery', row)
                return
            threads = []
            for role, attr in (('task', '_task_handler'), ('worker', '_worker_handler'), ('result', '_result_handler')):
                thread = vars(native_pool)[attr]
                if type(thread) is not threading.Thread:
                    threads.append({'pool_role': role, 'thread_object_id': id(thread),
                        'observation': 'UNKNOWN_UNSUPPORTED_THREAD_TYPE'})
                    continue
                target = self.delivery_target(thread)
                threads.append({'pool_role': role, 'thread_object_id': id(thread),
                    'thread_ident': vars(thread)['_ident'], 'thread_native_id': vars(thread)['_native_id'],
                    'thread_state': vars(thread).get('_state'),
                    'target': target, 'entry_target': self.delivery_thread_entries.get(id(thread))})
            row['pool_threads'] = threads
            row['product'] = self.calls[-1]['product'] if self.calls else None
        if code is threading.Thread.run.__code__:
            thread = state['self']
            if type(thread) is not threading.Thread:
                row['observation'] = 'UNKNOWN_UNSUPPORTED_THREAD_TYPE'
                row['thread_object_id'] = id(thread)
                self.save_parent('delivery', row)
                return
            row['thread_object_id'] = id(thread)
            if event == 'call':
                self.delivery_thread_entries[id(thread)] = self.delivery_target(thread)
            row['entry_target'] = self.delivery_thread_entries.get(id(thread))
        if code.co_name == 'invoke_excepthook':
            thread = state['thread']
            if type(thread) is not threading.Thread:
                row['observation'] = 'UNKNOWN_UNSUPPORTED_THREAD_TYPE'
                row['thread_object_id'] = id(thread)
                self.save_parent('delivery', row)
                return
            row['thread_object_id'] = id(thread)
            error_type = sys.exc_info()[0]
            row['active_exception_type'] = None if error_type is None else error_type.__module__ + '.' + error_type.__qualname__
        for name in ('result_job', 'i', 'size'):
            value = state.get(name)
            if type(value) is int:
                row[name] = value
        task = state.get('task') if code is pool.Pool._handle_tasks.__code__ else state.get('obj')
        if type(task) is tuple and len(task) >= 2 and type(task[0]) is type(task[1]) is int:
            row['job'], row['index'] = task[:2]
        if code is pool.MapResult._set.__code__:
            if type(state['self']) is not pool.MapResult:
                row['observation'] = 'UNKNOWN_UNSUPPORTED_MAPRESULT_TYPE'
                self.save_parent('delivery', row)
                return
            row['job'] = vars(state['self'])['_job']
            value = state['success_result']
            if type(value) is tuple and len(value) == 2 and value[0] is False:
                row['result_exception_type'] = type(value[1]).__module__ + '.' + type(value[1]).__qualname__
        if event == 'return' and type(arg) in (bytes, memoryview):
            row['returned_length'] = len(arg)
        self.save_parent('delivery', row)

    def bootstrap_observe(self, frame, event, arg=None):
        if frame.f_code not in self.bootstrap_functions:
            return
        if frame.f_globals is not self.bootstrap_functions[frame.f_code]:
            return
        if frame.f_code is not threading.Thread._bootstrap_inner.__code__ and event not in ('call', 'return'):
            return
        if frame.f_code is threading.Thread._bootstrap_inner.__code__ and event != 'audit_sys_setprofile':
            thread = frame.f_locals.get('self')
            if type(thread) is threading.Thread and id(thread) in self.bootstrap_first:
                return
        ticket = next(self.bootstrap_tickets)
        if ticket >= 64:
            self.bootstrap_fail('UNKNOWN_RECORD_LIMIT', RuntimeError('bootstrap record limit'))
        try:
            frame_pin(frame, self.pins, frame.f_code.co_name)
            thread = frame.f_locals.get('self')
            row = {'function': frame.f_code.co_name, 'actual_event': event,
                'caller_ident': threading.get_ident(), 'caller_native_id': threading.get_native_id(),
                'code_id': id(frame.f_code), 'source_sha256': self.pins[str(Path(frame.f_code.co_filename).resolve())]}
            if type(thread) is not threading.Thread:
                row['observation'] = 'UNKNOWN_UNSUPPORTED_THREAD_TYPE'
            else:
                state = vars(thread)
                object_id = id(thread)
                row.update(thread_object_id=object_id, thread_ident=state.get('_ident'),
                    thread_native_id=state.get('_native_id'))
                if frame.f_code is threading.Thread.start.__code__ and event == 'call':
                    self.bootstrap_first.discard(object_id)
                    self.bootstrap_targets.pop(object_id, None)
                    start_ticket = next(self.bootstrap_start_tickets)
                    if start_ticket >= 16:
                        raise RuntimeError('bootstrap start limit')
                    self.bootstrap_targets[object_id] = self.delivery_target(thread)
                    row['start_ticket'] = start_ticket
                row['retained_target'] = self.bootstrap_targets.get(object_id)
                if frame.f_code is threading.Thread._bootstrap_inner.__code__:
                    if event == 'audit_sys_setprofile':
                        expected = frame.f_globals.get('_profile_hook')
                        row['expected_callback_is_guard'] = (type(expected) is types.MethodType
                            and expected.__self__ is self and expected.__func__ is ParentGuard.profile)
                        if not row['expected_callback_is_guard']:
                            raise RuntimeError('bootstrap callback mismatch')
                        row['installation_success'] = 'UNKNOWN_AUDIT_PREINSTALL_ONLY'
                    else:
                        if object_id in self.bootstrap_first:
                            return
                        self.bootstrap_first.add(object_id)
                        row['first_observed_bootstrap_event'] = True
                        row['actual_c_function_is_setprofile'] = arg is sys.setprofile
                if frame.f_code is threading.Thread.join.__code__:
                    timeout = frame.f_locals.get('timeout')
                    row['timeout'] = timeout if type(timeout) in (int, float, type(None)) else 'UNKNOWN'
                    caller = vars(threading)['_active'].get(row['caller_ident'])
                    row['caller_object_id'] = id(caller) if type(caller) is threading.Thread else None
                    row['caller_retained_target'] = self.bootstrap_targets.get(row['caller_object_id'])
                    if event == 'return':
                        row['completion_observed'] = state.get('_is_stopped') is True
                        row['return_is_completion_proof'] = row['completion_observed']
                        row['return_value_is_none'] = arg is None
            self.bootstrap_rows.append(row)
            self.save_parent('bootstrap_observation', row)
        except Exception as error:
            self.bootstrap_fail('UNKNOWN_OBSERVER_OR_RECORDER_FAILURE', error)

    def bootstrap_fail(self, observation, error):
        ticket = next(self.bootstrap_error_tickets)
        if ticket < 16:
            row = {'observation': observation, 'error_ticket': ticket,
                'exception_type': type(error).__module__ + '.' + type(error).__qualname__}
            self.bootstrap_errors.append(row)
            sys.stderr.write(json.dumps({'bootstrap_recorder_error': row}) + '\n')
            sys.stderr.flush()
        raise error

    def product_frame(self, frame):
        while frame is not None:
            if frame.f_code.co_filename == str(self.worker_file) and frame.f_code.co_name == 'mp_process':
                assert O.sha(self.worker_file) == self.source['file_sha256'][str(self.worker_file.relative_to(self.source['root']))]
                native = frame.f_globals['MultiprocessingGenerateWorker'].__dict__['mp_process']
                assert native.__code__ is frame.f_code
                native_call(frame.f_locals['statement'].full_name, frame.f_locals['chunks'], self.receipt)
                return frame
            frame = frame.f_back
        raise RuntimeError('spawn has no exact native CSV mp_process caller')

    def profile(self, frame, event, arg):
        self.bootstrap_observe(frame, event, arg)
        O.observe_ipv6_close(frame, event, arg, self.receipt)
        if event == 'c_call' and arg is _posixsubprocess.fork_exec:
            assert id(frame) in self.active, 'unbound fork_exec rejected'
            frame_pin(frame, self.pins, 'spawnv_passfds')
            assert frame.f_code is util.spawnv_passfds.__code__
        if frame.f_code.co_filename == str(self.worker_file) and frame.f_code.co_name == 'mp_process' and event == 'call':
            native = self.product_frame(frame)
            product = native.f_locals['statement'].full_name
            assert product not in [c['product'] for c in self.calls]
            self.calls.append({'product': product, 'chunks': [[0, 1], [1, 1]], 'pid': os.getpid(), 'source_sha256': O.sha(self.worker_file)})
            self.save_parent('native_mp_call', self.calls[-1])
        if frame.f_code is util.spawnv_passfds.__code__:
            if event == 'call':
                product = self.product_frame(frame)
                caller = frame.f_back
                name = caller.f_code.co_name
                assert name in ('ensure_running', '_launch')
                frame_pin(caller, self.pins, name)
                role = 'tracker' if name == 'ensure_running' else 'worker'
                args, path, fds = (frame.f_locals[k] for k in ('args', 'path', 'passfds'))
                descriptors = dict(caller.f_locals)
                if role == 'worker':
                    process = caller.f_locals['process_obj']
                    assert process._target is pool.worker and process.daemon is True
                    inqueue, outqueue, initializer, initargs, maxtasks, wrap_exception = process._args
                    assert type(inqueue) is type(outqueue) is queues.SimpleQueue
                    assert initializer is None and initargs == () and maxtasks is None and wrap_exception is True
                    descriptors['queue_fds'] = [q._reader.fileno() for q in (inqueue,outqueue)] + [q._writer.fileno() for q in (inqueue,outqueue)]
                spawn_arguments(role, path, args, fds, self.manifest['python']['path'], util._args_from_interpreter_flags(), descriptors)
                spawn_budget(self.spawns, role, product.f_locals['statement'].full_name)
                row = {'role': role, 'product': product.f_locals['statement'].full_name, 'argv': [os.fsdecode(a) for a in args], 'passfds': list(fds), 'caller': str(Path(caller.f_code.co_filename).resolve()), 'caller_sha256': O.sha(Path(caller.f_code.co_filename)), 'pid': None}
                self.spawns.append(row)
                self.active[id(frame)] = row
                self.save_parent('spawn_bound_before_fork', row)
            elif event == 'return':
                assert type(arg) is int and arg > 0
                row = self.active.pop(id(frame))
                row['pid'] = arg
                self.save_parent('spawn_returned_pid', row)
        self.delivery(frame, event, arg)
        self.record.observe(frame, event, arg)

    def verify(self):
        assert not self.bootstrap_errors, 'bootstrap observation invalid; captured stderr retains errors'
        assert [c['product'] for c in self.calls] == ['people1', 'people2']
        assert len(self.spawns) == 5 and not self.active
        assert sum(s['role'] == 'tracker' for s in self.spawns) == 1
        assert len({s['pid'] for s in self.spawns}) == 5
        events = [json.loads(line) for path in self.child.glob('events.*.jsonl') for line in path.read_text().splitlines()]
        wrappers = [r for r in events if r['function'] == 'mp_wrapper' and r['event'] == 'call']
        returned = [r for r in events if r['function'] == 'mp_wrapper' and r['event'] == 'return']
        expected = {('people1',1,(0,1)),('people1',2,(1,1)),('people2',1,(0,1)),('people2',2,(1,1))}
        graph = lambda rows: {(r['product'],r['worker_id'],tuple(r['chunk'])) for r in rows}
        assert len(wrappers) == len(returned) == 4 and graph(wrappers) == graph(returned) == expected
        pids = {s['pid'] for s in self.spawns if s['role'] == 'worker'}
        assert all(r['pid'] in pids and r['ppid'] == os.getpid() and r['start_method'] == 'spawn' for r in wrappers)
        guards = [json.loads(line) for path in self.child.glob('worker-guard-*.jsonl') for line in path.read_text().splitlines()]
        assert not any(r['phase'] == 'effect_refused' for r in guards)
        assert sum(r['phase'] == 'native_wrapper' for r in guards) == 4
        assert sum(r['phase'] == 'native_wrapper_return' for r in guards) == 4
        executed = {r['pid'] for r in wrappers}
        assert executed <= {r['pid'] for r in guards if r['phase'] == 'ipv6_closed'}
        pool_calls = sorted((r for r in events if r['function']=='map' and r['event']=='call'),key=lambda r:r['time_ns'])
        assert len(pool_calls)==2
        for product,row in zip(('people1','people2'),pool_calls,strict=True):
            assert {p['pid'] for p in row['pool_processes']} == {s['pid'] for s in self.spawns if s['role']=='worker' and s['product']==product}
        self.receipt['mp2'].update(status='PASS_NATIVE_MP2_SOURCE_BOUND_GRAPH', actual_wrapper_calls=wrappers,
            native_pool_calls=pool_calls,executing_worker_pids=sorted(executed),
            startup_observed_pids=sorted({r['pid'] for r in guards if r['phase']=='startup'}),
            limitation='Idle workers may be terminated before startup receipt; no claim that every spawned worker executes a chunk or imports CE. All actual wrapper entries are guarded by exact native code identity.')

    def audit(self, event, args):
        if event == 'sys.setprofile':
            frame = sys._getframe(1)
            if (frame.f_globals is vars(O) and frame.f_code.co_name == '<lambda>'
                    and frame.f_code in O.child_run.__code__.co_consts):
                frame = frame.f_back
            if (frame is not None and frame.f_code is threading.Thread._bootstrap_inner.__code__
                    and frame.f_globals is vars(threading) and frame.f_lineno == 1042):
                self.bootstrap_observe(frame, 'audit_sys_setprofile')
        if event in ('object.__getattr__', 'sys._getframe'):
            return
        if event == 'os.kill':
            assert args[0] in {s['pid'] for s in self.spawns if s['role'] == 'worker'}
            frame = sys._getframe(1)
            while frame is not None and frame.f_code.co_name != '_send_signal':
                frame = frame.f_back
            assert frame is not None
            frame_pin(frame, self.pins, '_send_signal')
        O.audit_policy(event, args, self.child.resolve(), self.receipt)


def install_worker():
    import record_process
    B = O.BASE
    child = Path(os.environ['CE_CSV_RUN']).resolve()
    label = os.environ['CE_CSV_LABEL']
    assert child == B / 'runs' / 'part' / label / 'child'
    O.check_authorization('part', label)
    O.check_freeze()
    manifest = json.loads(O.MANIFEST.read_text())
    O.check_interpreter(manifest)
    source = manifest['sources'][label]
    assert os.environ['STEP193_SOURCE'] == source['root']
    assert os.environ['STEP193_EVENTS'] == str(child / 'events')
    owner = json.loads((child / 'mp-owner.json').read_text())
    assert os.getppid() == owner['pid'] and os.getpgid(0) == owner['pgid'] == owner['pid']
    assert sys.getprofile() is None
    receipt = {'audit': {'opens': [], 'mutations': [], 'forbidden': []}}
    out = child / ('worker-guard-%d.jsonl' % os.getpid())
    def save(row):
        with out.open('a') as stream:
            stream.write(json.dumps(dict(row, monotonic_ns=time.monotonic_ns())) + '\n')
    save({'phase': 'startup', 'pid': os.getpid(), 'ppid': os.getppid(), 'pgid': os.getpgid(0), 'argv': sys.orig_argv, 'python': manifest['python'], 'source': source['commit']})
    def audit(event, args):
        try:
            assert event != 'os.kill', 'worker process signaling refused'
            O.audit_policy(event, args, child, receipt)
        except BaseException:
            save({'phase':'effect_refused', 'pid':os.getpid(), 'audit':receipt['audit']})
            raise
    sys.addaudithook(audit)
    stack_stream = (child / ('worker-stack-at-45s-%d.txt' % os.getpid())).open('x')
    faulthandler.dump_traceback_later(45, repeat=False, file=stack_stream, exit=False)
    save({'phase': 'worker_stack_armed', 'pid': os.getpid(), 'delay_seconds': 45, 'repeat': False})
    def close_diagnostic():
        faulthandler.cancel_dump_traceback_later()
        stack_stream.close()
    atexit.register(close_diagnostic)
    def profile(frame, event, arg):
        worker_fork_guard(event, arg)
        O.observe_ipv6_close(frame, event, arg, receipt)
        if (event == 'return' and frame.f_code.co_name == '_has_ipv6'
                and frame.f_code.co_filename == str(O.PROBE_FILE)
                and O.ipv6_probe_frame(frame) is frame):
            O.check_ipv6_probe(receipt)
            save({'phase':'ipv6_closed', 'pid':os.getpid(), 'probe':receipt['audit']['ipv6_probe']})
        if event == 'call' and frame.f_code.co_name == 'mp_wrapper' and frame.f_code.co_filename.startswith(source['root'] + '/datamimic_ce/'):
            worker_path = Path(source['root']) / manifest['spawn']['worker_paths'][label]
            assert frame.f_code.co_filename == str(worker_path)
            assert O.sha(worker_path) == source['file_sha256'][str(worker_path.relative_to(source['root']))]
            assert frame.f_code is frame.f_globals['MultiprocessingGenerateWorker'].__dict__['mp_wrapper'].__func__.__code__
            _, stmt, worker_id, start, end, _ = frame.f_locals['args']
            assert stmt.full_name in ('people1','people2') and (worker_id,start,end) in ((1,0,1),(2,1,1))
            origins = [O.check_origin(name, module.__file__, source) for name, module in tuple(sys.modules.items()) if (name == 'datamimic_ce' or name.startswith('datamimic_ce.')) and isinstance(module.__dict__.get('__file__'), str)]
            O.check_ipv6_probe(receipt)
            save({'phase':'native_wrapper', 'pid':os.getpid(), 'origins':origins, 'forbidden':receipt['audit']['forbidden']})
        record_process.observe(frame, event, arg)
        if event == 'return' and frame.f_code.co_name == 'mp_wrapper' and frame.f_code.co_filename.startswith(source['root'] + '/datamimic_ce/'):
            save({'phase':'native_wrapper_return', 'pid':os.getpid(), 'audit':receipt['audit']})
    sys.setprofile(profile)
    save({'phase': 'worker_profile_installed', 'pid': os.getpid()})
