import json,sys,subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
sys.path.insert(0,'/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
sys.meta_path[:]=[finder for finder in sys.meta_path if not getattr(finder,'__module__','').startswith('__editable__')]
from datamimic_ce.data_mimic_test import DataMimicTest
SOURCE=Path('/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
records=[]
for case in ('static_xml','dynamic_xml','static_properties','dynamic_properties'):
 with TemporaryDirectory(prefix='ce-include-original-',dir='/private/tmp') as directory:
  base=Path(directory)
  (base/'child.xml').write_text('<setup reportLogging="False"><generate name="child" count="2"><key name="value" constant="ok"/></generate></setup>')
  (base/'child.properties').write_text('row_count=2\n')
  suffix='xml' if case.endswith('xml') else 'properties'; target='child.'+suffix; dynamic=case.startswith('dynamic')
  variable=f'<variable name="include_path" constant="{target}"/>' if dynamic else ''
  uri='{include_path}' if dynamic else target
  generate='<generate name="child" count="{row_count}"><key name="value" constant="ok"/></generate>' if suffix=='properties' else ''
  (base/'main.xml').write_text(f'<setup rngSeed="1" reportLogging="False">{variable}<include uri="{uri}"/>{generate}</setup>')
  try:
   engine=DataMimicTest(base,'main.xml',capture_test_result=True); engine.test_with_timer(); result=engine.capture_result()
   assert result=={'child':[{'value':'ok'},{'value':'ok'}]},result
   records.append({'case':case,'status':'PASS'})
  except Exception as e:
   records.append({'case':case,'status':'FAIL','exception_type':type(e).__name__})
assert [r['status'] for r in records]==['PASS','FAIL','PASS','PASS'],records
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'source_module':sys.modules['datamimic_ce.data_mimic_test'].__file__,'cases':records,'meaning':'legacy original runtime include repro only'}
out=Path('/private/tmp/ce-final-parity-ledger-20261012/include-original-legacy-receipt.json');out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'head':receipt['head'],'cases':records}))
