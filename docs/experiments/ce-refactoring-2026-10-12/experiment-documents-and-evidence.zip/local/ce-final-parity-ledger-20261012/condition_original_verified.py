import hashlib,json,sys
from pathlib import Path
ORIG=Path('/private/tmp/ce-final-parity-ledger-20261012/original-clone').resolve(); root=ORIG/'datamimic_ce/demos/demo-condition'
sys.path.insert(0,str(ORIG));sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable__')]
from datamimic_ce.data_mimic_test import DataMimicTest

def check_origins():
 modules=[(n,m) for n,m in sys.modules.items() if n=='datamimic_ce' or n.startswith('datamimic_ce.')]
 for name,m in modules:
  p=getattr(m,'__file__',None)
  if p: assert Path(p).resolve().is_relative_to(ORIG),(name,p)
 return len(modules)
check_origins();files=list(root.glob('*.xml'));assert len(files)==5
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
engine=DataMimicTest(root,'datamimic.xml',capture_test_result=True);engine.test_with_timer();c=engine.capture_result();n=check_origins()
assert {k:len(v) for k,v in c.items()}=={'condition':10,'bike':10,'group_name_not_override':10,'group':10,'big_group':1}
issues=[]
for key,expected in {'emptyList':'[]','emptyList2':'[]','emptyList3':None,'emptyDict':'{}','emptyDict2':'{}','emptyDict3':None}.items():
 actual=c['group_name_not_override'][0][key]
 if actual!=expected:issues.append({'field':key,'comment_expected':expected,'actual':actual})
for key in ('removeElement','removeElementorEmpty'):
 if key in c['group_name_not_override'][0]:issues.append({'field':key,'comment_expected':'absent','actual':c['group_name_not_override'][0][key]})
receipt={'head':'a219163e533d661bcc7bda0faa5ecc77909ab5aa','source_root':str(ORIG),'entry_module':sys.modules['datamimic_ce.data_mimic_test'].__file__,'loaded_datamimic_modules_after':n,'all_loaded_modules_from_source_root':True,'input_hashes':hashes,'counts':{k:len(v) for k,v in c.items()},'comment_counterexamples':issues,'unseeded_coverage':{'bike_years':sorted({r['year'] for r in c['bike']})},'meaning':'bounded original condition demo run and comment comparison only'}
Path('/private/tmp/ce-final-parity-ledger-20261012/condition-original-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'head':receipt['head'],'module_count':n,'counts':receipt['counts'],'counterexamples':len(issues),'hashes':hashes}))
