import json,sys,subprocess,hashlib,logging
from pathlib import Path
from tempfile import TemporaryDirectory
logging.disable(logging.CRITICAL)
ORIG=Path('/private/tmp/ce-final-parity-ledger-20261012/original-clone').resolve()
sys.path.insert(0,str(ORIG));sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable__')]
from datamimic_ce.data_mimic_test import DataMimicTest

def check_origins():
 modules=[(n,m) for n,m in sys.modules.items() if n=='datamimic_ce' or n.startswith('datamimic_ce.')]
 for name,m in modules:
  p=getattr(m,'__file__',None)
  if p: assert Path(p).resolve().is_relative_to(ORIG),(name,p)
 return len(modules)
check_origins();records=[]
for case in ('static_xml','dynamic_xml','static_properties','dynamic_properties'):
 with TemporaryDirectory(prefix='ce-include-original-verified-',dir='/private/tmp') as directory:
  base=Path(directory)
  (base/'child.xml').write_text('<setup reportLogging="False"><generate name="child" count="2"><key name="value" constant="ok"/></generate></setup>')
  (base/'child.properties').write_text('row_count=2\n')
  suffix='xml' if case.endswith('xml') else 'properties'; target='child.'+suffix; dynamic=case.startswith('dynamic')
  variable=f'<variable name="include_path" constant="{target}"/>' if dynamic else ''
  uri='{include_path}' if dynamic else target
  generate='<generate name="child" count="{row_count}"><key name="value" constant="ok"/></generate>' if suffix=='properties' else ''
  (base/'main.xml').write_text(f'<setup rngSeed="1" reportLogging="False">{variable}<include uri="{uri}"/>{generate}</setup>')
  try:
   engine=DataMimicTest(base,'main.xml',capture_test_result=True);engine.test_with_timer();result=engine.capture_result()
   assert result=={'child':[{'value':'ok'},{'value':'ok'}]},result
   records.append({'case':case,'status':'PASS'})
  except Exception as e: records.append({'case':case,'status':'FAIL','exception_type':type(e).__name__})
  n=check_origins()
assert [r['status'] for r in records]==['PASS','FAIL','PASS','PASS'],records
receipt={'head':'a219163e533d661bcc7bda0faa5ecc77909ab5aa','source_root':str(ORIG),'entry_module':sys.modules['datamimic_ce.data_mimic_test'].__file__,'loaded_datamimic_modules_after':n,'all_loaded_modules_from_source_root':True,'cases':records,'meaning':'legacy original runtime include repro; isolated temporary descriptors only'}
Path('/private/tmp/ce-final-parity-ledger-20261012/include-original-legacy-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'head':receipt['head'],'all_modules_source_root':receipt['all_loaded_modules_from_source_root'],'module_count':n,'cases':records}))
