import sys
sys.path.insert(0,'/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
print(sys.path[:3]); print(sys.meta_path)
import datamimic_ce
print(datamimic_ce.__file__,datamimic_ce.__path__)
