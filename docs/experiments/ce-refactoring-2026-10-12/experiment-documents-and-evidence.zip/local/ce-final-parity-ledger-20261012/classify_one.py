import sys
from pathlib import Path
ORIG=Path('/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
ROOT=Path('/private/tmp/ce-literal-source-arms-candidate-20261011')
sys.path.insert(0,str(ORIG))
from datamimic_ce.engine.dsl.api import DescriptorParser
from datamimic_ce.engine.io.api import load_connection_profile
import re
def is_credential(message):
 fields=set(re.findall(r'-\s*(\w+):\s*Field required',message))
 return 'make sure all required attributes are provided' in message and bool(fields) and fields <= {'host','port','database','user','password'}
p=ROOT/'tests_ce/unit_tests/test_authoring/fixtures/fx_upsert_zero.xml'
try: DescriptorParser.parse(p,None,'production',profile_loader=load_connection_profile)
except Exception as e:
 print(type(e).__name__,is_credential(str(e)))
