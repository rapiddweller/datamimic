import ast,json
from pathlib import Path
root=Path('/private/tmp/ce-literal-source-arms-candidate-20261011')
rows=[json.loads(x) for x in Path('/private/tmp/ce-step210-ledger.jsonl').read_text().splitlines() if json.loads(x).get('planning_lane')=='intentionally-invalid']
out=[]
for row in rows:
 name=Path(row['path']).name; found=[]; parent=root/Path(row['path']).parent
 for f in parent.glob('test_*.py'):
  lines=f.read_text().splitlines()
  try: tree=ast.parse('\n'.join(lines))
  except Exception: continue
  class V(ast.NodeVisitor):
   def __init__(self): self.classes=[]
   def visit_ClassDef(self,n): self.classes.append(n.name); self.generic_visit(n); self.classes.pop()
   def visit_FunctionDef(self,n):
    if n.name.startswith('test_') and name in '\n'.join(lines[n.lineno-1:n.end_lineno]): found.append(str(f.relative_to(root))+'::'+'::'.join(self.classes+[n.name]))
    self.generic_visit(n)
  V().visit(tree)
 out.append({'path':row['path'],'source_sha256':row['current_c992']['xml_sha256'],'pytest_owner_nodes':found})
Path('/private/tmp/ce-final-parity-ledger-20261012/invalid-owner-nodes.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in out))
assert len(out)==70 and all(x['pytest_owner_nodes'] for x in out)
print(json.dumps({'paths':len(out),'owner_nodes':len({n for r in out for n in r['pytest_owner_nodes']}),'all_owned':all(x['pytest_owner_nodes'] for x in out)}))
