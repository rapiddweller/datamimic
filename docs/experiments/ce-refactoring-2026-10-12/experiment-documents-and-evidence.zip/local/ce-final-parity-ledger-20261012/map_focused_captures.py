import json,hashlib
from pathlib import Path
inputs={r['path']:r for r in map(json.loads,Path('/private/tmp/ce-dsl-all-inputs-20261012/checks.jsonl').read_text().splitlines())}
rows=[]
for cmp in sorted(Path('/private/tmp').glob('ce-dsl-step*/cases/*/comparison.json')):
 d=json.loads(cmp.read_text()); pre=Path(d['preflight']['path']); pd=json.loads(pre.read_text()) if pre.exists() else {}
 src=pd.get('source',{}); orig=src.get('original',{}); cur=src.get('current',{})
 for path in d.get('xml_order',[]):
  oh=(orig.get('tracked',{}).get(path) or {}).get('sha256'); ch=(cur.get('tracked',{}).get(path) or {}).get('sha256'); matrix=inputs.get(path)
  rows.append({'receipt':str(cmp),'source_path':path,'current_input_sha256':matrix.get('sha256') if matrix else None,'original_source_sha256':oh,'current_source_sha256':ch,'original_current_source_hash_equal':bool(oh and ch and oh==ch),'path_in_931_manifest':matrix is not None,'owner_node':d.get('nodeid'),'original_head':d.get('original_head'),'comparison_head':d.get('current_head'),'capture_sha256':d.get('complete_capture_sha256'),'typed_capture_equal':d.get('typed_capture_equal_across_both_endpoints'),'receipt_status':d.get('status'),'frozen_oracle_parity':d.get('frozen_oracle_parity')})
out=Path('/private/tmp/ce-final-parity-ledger-20261012/focused-capture-family-map.jsonl');out.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
print(json.dumps({'rows':len(rows),'source_hash_equal':sum(r['original_current_source_hash_equal'] for r in rows),'exact_path_manifest':sum(r['path_in_931_manifest'] for r in rows),'capture_equal':sum(r['typed_capture_equal'] is True for r in rows),'receipt_statuses':{k:sum(r['receipt_status']==k for r in rows) for k in set(r['receipt_status'] for r in rows)},'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
