import json
import platform
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
sys.meta_path[:] = [finder for finder in sys.meta_path if not getattr(finder, '__module__', '').startswith('__editable__')]
from tempfile import TemporaryDirectory
from datamimic_ce.engine.runtime.api import create_run_session
from datamimic_ce.engine.runtime.contracts import RunRequest
from datamimic_ce.engine.runtime.tasks.setup import include_task

SOURCE = Path('/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
records = []
for case in ('static_xml', 'dynamic_xml', 'static_properties', 'dynamic_properties'):
    with TemporaryDirectory(prefix='ce-include-proof-', dir='/private/tmp') as directory:
        base = Path(directory)
        (base / 'child.xml').write_text('<setup reportLogging="False"><generate name="child" count="2"><key name="value" constant="ok"/></generate></setup>', encoding='utf-8')
        (base / 'child.properties').write_text('row_count=2\n', encoding='utf-8')
        suffix = 'xml' if case.endswith('xml') else 'properties'
        target = 'child.' + suffix
        dynamic = case.startswith('dynamic')
        variable = f'<variable name="include_path" constant="{target}"/>' if dynamic else ''
        uri = '{include_path}' if dynamic else target
        generate = '<generate name="child" count="{row_count}"><key name="value" constant="ok"/></generate>' if suffix == 'properties' else ''
        (base / 'main.xml').write_text(f'<setup rngSeed="1" reportLogging="False">{variable}<include uri="{uri}"/>{generate}</setup>', encoding='utf-8')
        try:
            session = create_run_session(RunRequest(descriptor_path=base / 'main.xml', test_mode=True))
            session.execute()
            result = session.capture_test_result()
            assert result == {'child': [{'value': 'ok'}, {'value': 'ok'}]}, result
            records.append({'case': case, 'status': 'PASS', 'result': result})
        except FileNotFoundError as error:
            records.append({'case': case, 'status': 'FAIL', 'exception': type(error).__name__, 'message': str(error).replace(str(base), '<isolated-temp>')})
assert [r['status'] for r in records] == ['PASS', 'FAIL', 'PASS', 'PASS'], records
assert records[1]['message'] == "Descriptor file not found: '{include_path}'", records[1]
receipt = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(), 'python': platform.python_version(), 'executable': sys.executable, 'source_module': include_task.__file__, 'cases': records, 'meaning': 'Confirmed runtime defect, not a product PASS or historical native parity.'}
Path('/private/tmp/ce-final-parity-ledger-20261012/include-original-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'head':receipt['head'],'cases':[{k:r[k] for k in ('case','status','exception') if k in r} for r in records]}))
