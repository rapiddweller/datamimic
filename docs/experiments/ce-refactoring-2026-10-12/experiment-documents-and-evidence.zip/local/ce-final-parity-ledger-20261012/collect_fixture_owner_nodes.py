import os,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve();os.chdir(root);node='tests_ce/unit_tests/test_authoring/test_rule_fixtures.py'
sys.path.insert(0,str(root));sys.path[:]=[p for i,p in enumerate(sys.path) if p not in ('/Users/akell/PycharmProjects/development-v2/datamimic','/private/tmp/ce-final-parity-ledger-20261012/original-clone','/private/tmp/ce-final-parity-ledger-20261012/current-clone') or i==0]
sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable__')]
import datamimic_ce
assert Path(datamimic_ce.__file__).resolve()==root/'datamimic_ce/__init__.py'
print('PACKAGE_ORIGIN',datamimic_ce.__file__)
import pytest
code=pytest.main(['--collect-only','-q',node])
for n,m in tuple(sys.modules.items()):
 if n=='datamimic_ce' or n.startswith('datamimic_ce.'):
  f=getattr(m,'__file__',None)
  if f: assert Path(f).resolve().is_relative_to(root),(n,f)
print('COLLECT_EXIT',int(code))
raise SystemExit(int(code))
