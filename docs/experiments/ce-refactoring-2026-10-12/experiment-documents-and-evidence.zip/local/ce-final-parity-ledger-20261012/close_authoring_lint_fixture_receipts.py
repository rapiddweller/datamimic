import hashlib, json
from pathlib import Path
p=Path('/private/tmp/ce-final-parity-ledger-20261012')
def readj(path): return [json.loads(x) for x in open(path)]
old=readj(p/'authoring-lint-fixture-original.jsonl'); cur=readj(p/'authoring-lint-fixture-current.jsonl')
ledger={x['path']:x for x in readj(Path('/private/tmp/ce-step210-ledger.jsonl')) if x['planning_lane']=='authoring-fixture'}
rows=[]; owners={}
for a,b in zip(old,cur):
 assert a['path']==b['path'] and a['source_sha256']==b['source_sha256']
 key=lambda d: [(x['code'],x['severity'],x['path']) for x in d['diagnostics']]
 assert a['status']==b['status']=='OK' and a['truncated']==b['truncated']==0
 assert key(a)==key(b) and [x['message_sha256'] for x in a['diagnostics']]==[x['message_sha256'] for x in b['diagnostics']]
 led=ledger[a['path']]; own=led['authoring_owner_map']; assert own and own['owner_status']=='OWNED'
 for node in own['owner_nodes']: owners[node]=owners.get(node,0)+1
 rows.append({'path':a['path'],'source_sha256':a['source_sha256'],'original_diagnostics':key(a),'current_diagnostics':key(b),'diagnostic_tuple_parity':True,'message_fingerprint_parity':True,'original_package_origin':a['package_origin'],'current_package_origin':b['package_origin'],'original_loaded_ce_modules':a['loaded_ce_modules'],'current_loaded_ce_modules':b['loaded_ce_modules'],'owner_nodes':own['owner_nodes'],'owner_test_mode':own['test_mode'],'owner_assertions':own['assertions'],'owner_status':led['authoring_owner_status']})
with open(p/'authoring-lint-fixture-comparison.jsonl','w') as f:
 for x in rows: f.write(json.dumps(x,sort_keys=True)+'\n')
s={'fixture_count':len(rows),'source_hashes_match_between_candidates':True,'canonical_linter_invoked':True,'module_origin_asserted_each_run':True,'diagnostic_code_severity_path_equal_count':sum(x['diagnostic_tuple_parity'] for x in rows),'message_fingerprint_equal_count':sum(x['message_fingerprint_parity'] for x in rows),'wording_amendments_required':0,'old_total_diagnostics':sum(len(x['original_diagnostics']) for x in rows),'current_total_diagnostics':sum(len(x['current_diagnostics']) for x in rows),'owner_status_all_owned':all(x['owner_status']=='OWNED_QA_VERIFIED_AT_12D5_AND_C65' for x in rows),'owner_node_input_counts':owners,'scope':'Canonical authoring lint only; no engine execution in this receipt. Fixture runtime/smoke ownership where declared by owner remains a separate test contract.','sources':{'original':'a219163e533d661bcc7bda0faa5ecc77909ab5aa','current':'384b7723d950d8b312b1080d23ffd89a5343c9b0'},'files':{'original_rows':'authoring-lint-fixture-original.jsonl','current_rows':'authoring-lint-fixture-current.jsonl','comparison_rows':'authoring-lint-fixture-comparison.jsonl'}}
(p/'authoring-lint-fixture-summary.json').write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
# update combined summary
sp=p/'summary.json'; main=json.loads(sp.read_text()); main['authoring_lint_fixture_parity']=s
for name in ['authoring-lint-fixture-original.jsonl','authoring-lint-fixture-current.jsonl','authoring-lint-fixture-comparison.jsonl','authoring-lint-fixture-summary.json']:
 main['artifacts'][name.replace('-','_').replace('.jsonl','').replace('.json','')+'_sha256']=hashlib.sha256((p/name).read_bytes()).hexdigest()
# receipt gets added below and its digest refreshed last
sp.write_text(json.dumps(main,indent=2,sort_keys=True)+'\n')
receipt=p/'receipt.md'; text=receipt.read_text(); text += '\nAuthoring diagnostic parity: 41 exact hash-verified authoring-fixture lane inputs were run through each candidate’s canonical authoring linter in one isolated process per source. Every loaded package module was origin-checked under the corresponding pinned archive. All 41 matched diagnostic code/severity/path tuples and message fingerprints (59 diagnostics per side); no wording amendments were needed. No engine execution is claimed by this receipt. All 41 have owner mappings in the frozen ledger: the rule-fixture parametrization covers 26 of these (the 28-row suite also includes two paths outside this lane), with the remaining 15 owned by one clean-linter check, three selector-lint checks, and 11 bounded dry-run/smoke-export tests. This is diagnostic parity, not a claim that the linter receipt itself exercises each runtime owner. See `authoring-lint-fixture-comparison.jsonl` and `authoring-lint-fixture-summary.json`.\n'
receipt.write_text(text)
main=json.loads(sp.read_text()); main['artifacts']['receipt_md_sha256']=hashlib.sha256(receipt.read_bytes()).hexdigest(); sp.write_text(json.dumps(main,indent=2,sort_keys=True)+'\n')
print(json.dumps(s,indent=2))
