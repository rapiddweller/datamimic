import hashlib,json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic')
sys.meta_path[:]=[finder for finder in sys.meta_path if not getattr(finder,'__module__','').startswith('__editable__')]
from datamimic_ce.data_mimic_test import DataMimicTest
root=Path('/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic/datamimic_ce/demos/demo-condition')
files=list(root.glob('*.xml'))
assert len(files)==5
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
engine=DataMimicTest(root,'datamimic.xml',capture_test_result=True);engine.test_with_timer(); c=engine.capture_result()
assert {k:len(v) for k,v in c.items()}=={'condition':10,'bike':10,'group_name_not_override':10,'group':10,'big_group':1}
issues=[]
for key,expected in {'emptyList':'[]','emptyList2':'[]','emptyList3':None,'emptyDict':'{}','emptyDict2':'{}','emptyDict3':None}.items():
 actual=c['group_name_not_override'][0][key]
 if actual!=expected: issues.append({'field':key,'comment_expected':expected,'actual':actual})
for key in ('removeElement','removeElementorEmpty'):
 if key in c['group_name_not_override'][0]: issues.append({'field':key,'comment_expected':'absent','actual':c['group_name_not_override'][0][key]})
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic',text=True).strip(),'source_root':str(root),'input_hashes':hashes,'counts':{k:len(v) for k,v in c.items()},'semantic_controls':'count shape PASS','comment_counterexamples':issues,'unseeded_coverage':{'bike_years':sorted({r['year'] for r in c['bike']})}}
out=Path('/private/tmp/ce-final-parity-ledger-20261012/condition-original-receipt.json');out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('head','counts','comment_counterexamples','unseeded_coverage')}))
