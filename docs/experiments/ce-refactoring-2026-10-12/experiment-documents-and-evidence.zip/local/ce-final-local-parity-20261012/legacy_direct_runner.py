import hashlib,inspect,json,os,pathlib,subprocess,sys,time
base=pathlib.Path('/private/tmp/ce-final-local-parity-20261012');root=base/'original-tree'
cases=json.loads((base/'case_paths.json').read_text());python=pathlib.Path('/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python')
code=r'''import hashlib,inspect,json,os,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve(); p=Path(sys.argv[2]).resolve(); expected=hashlib.sha256(p.read_bytes()).hexdigest(); events=[]; outside=[]
from datamimic_ce.data_mimic_test import DataMimicTest
from datamimic_ce.parsers.descriptor_parser import DescriptorParser
from datamimic_ce.datamimic import DataMimic
for obj in (DataMimicTest,DescriptorParser,DataMimic):
 origin=Path(inspect.getfile(obj)).resolve()
 try: origin.relative_to(root)
 except ValueError: outside.append(str(origin))
orig_parse=DescriptorParser.parse; orig_run=DataMimic.parse_and_execute

def parse(path,*args,**kwargs):
 q=Path(path).resolve(); digest=hashlib.sha256(q.read_bytes()).hexdigest()
 try: result=orig_parse(path,*args,**kwargs)
 except BaseException as e: events.append({'kind':'parse','path':str(q),'sha256':digest,'outcome':'failed','error':type(e).__name__}); raise
 events.append({'kind':'parse','path':str(q),'sha256':digest,'outcome':'returned'}); return result

def run(self,*args,**kwargs):
 events.append({'kind':'runtime_start','path':str(self._descriptor_path.resolve())})
 try: result=orig_run(self,*args,**kwargs)
 except BaseException as e: events.append({'kind':'runtime_end','outcome':'failed','error':type(e).__name__}); raise
 events.append({'kind':'runtime_end','outcome':'returned'}); return result
DescriptorParser.parse=staticmethod(parse);DataMimic.parse_and_execute=run
outcome='returned'; error=None
try: DataMimicTest(test_dir=p.parent,filename=p.name).test_with_timer()
except BaseException as e: outcome='error'; error=type(e).__name__+':'+str(e)[:180]
for name,module in tuple(sys.modules.items()):
 if name.startswith('datamimic_ce') and getattr(module,'__file__',None):
  try: Path(module.__file__).resolve().relative_to(root)
  except ValueError: outside.append(name)
print('RECEIPT:'+json.dumps({'path':str(p.relative_to(root)),'sha256':expected,'outcome':outcome,'error':error,'events':events,'outside_module_count':len(set(outside)),'outside_modules':sorted(set(outside)),'api_modules':{'DataMimicTest':inspect.getfile(DataMimicTest),'DescriptorParser':inspect.getfile(DescriptorParser),'DataMimic':inspect.getfile(DataMimic)}}))
'''
rows=[];env=os.environ.copy();env.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1')
for rel in cases:
 p=root/rel; started=time.monotonic()
 r=subprocess.run([str(python),'-c',code,str(root),str(p)],cwd=p.parent,env=env,capture_output=True,text=True,timeout=30)
 line=next((x for x in reversed(r.stdout.splitlines()) if x.startswith('RECEIPT:')),None)
 if line is None: rows.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'outcome':'unavailable','error':(r.stderr.splitlines()[-1][:200] if r.stderr.splitlines() else 'no receipt'),'outside_module_count':None})
 else:
  row=json.loads(line.removeprefix('RECEIPT:')); row['elapsed_seconds']=round(time.monotonic()-started,3);rows.append(row)
 (base/'legacy-direct.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
print('done',len(rows),flush=True)
