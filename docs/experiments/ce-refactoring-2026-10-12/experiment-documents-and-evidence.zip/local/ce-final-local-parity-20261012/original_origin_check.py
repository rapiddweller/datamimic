import json, os, pathlib, shutil, subprocess, sys, time
sys.path.insert(0,'/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011')
from process_group_guard import wait_for_process_group
B=pathlib.Path('/private/tmp/ce-final-local-parity-20261012'); root=B/'original-tree'; py='/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python'
cases=[('demo-ecommerce','datamimic_ce/demos/demo-ecommerce','datamimic.xml'),('single_json','tests_ce/integration_tests/test_exporters','single_json.xml'),('single_txt','tests_ce/integration_tests/test_exporters','single_txt.xml'),('single_xml','tests_ce/integration_tests/test_exporters','single_xml.xml')]
code=r'''import json,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve(); p=Path(sys.argv[2]).resolve()
from datamimic_ce.data_mimic_test import DataMimicTest
DataMimicTest(test_dir=p.parent,filename=p.name).test_with_timer()
out=[]
for name,m in tuple(sys.modules.items()):
 if name.startswith('datamimic_ce') and getattr(m,'__file__',None):
  try: Path(m.__file__).resolve().relative_to(root)
  except ValueError: out.append({'name':name,'file':str(Path(m.__file__).resolve())})
print('ORIGIN:'+json.dumps({'file':str(Path(DataMimicTest.__module__ and sys.modules[DataMimicTest.__module__].__file__).resolve()),'loaded_datamimic_modules':sum(1 for n,m in sys.modules.items() if n.startswith('datamimic_ce') and getattr(m,'__file__',None)),'outside_modules':out}))
'''
rows=[]
for name,sub,fn in cases:
 dest=B/'origin-check'/name/'work'
 if dest.exists(): shutil.rmtree(dest)
 shutil.copytree(root/sub,dest)
 env=os.environ.copy();env.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1')
 p=subprocess.Popen([py,'-c',code,str(root),str(dest/fn)],cwd=dest,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 out,_=p.communicate(timeout=240); guard=wait_for_process_group(p,0.1)
 marker=next((l[7:] for l in out.splitlines() if l.startswith('ORIGIN:')),None)
 rows.append({'case':name,'exit_code':p.returncode,'cleanup_ok':guard['cleanup_ok'],'provenance':json.loads(marker) if marker else None,'log_tail':'\n'.join(out.splitlines()[-4:])})
(B/'original-origin-check.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
print(json.dumps([{k:v for k,v in x.items() if k!='log_tail'} for x in rows],sort_keys=True))
