import hashlib,json,os,pathlib,subprocess,time
base=pathlib.Path('/private/tmp/ce-final-local-parity-20261012'); root=base/'original-tree'
cases=json.loads((base/'case_paths.json').read_text())
python=pathlib.Path('/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python')
code='''import sys\nfrom pathlib import Path\nfrom datamimic_ce.data_mimic_test import DataMimicTest\np=Path(sys.argv[1])\ntry:\n DataMimicTest(test_dir=p.parent, filename=p.name).test_with_timer()\n print("RESULT:RETURNED")\nexcept BaseException as e:\n print("RESULT:ERROR:"+type(e).__name__+":"+str(e)[:240])\n'''
env=os.environ.copy();env.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1')
allrows=[json.loads(x) for x in (base/'runs.jsonl').read_text().splitlines() if json.loads(x)['revision']=='current']
for rel in cases:
 p=root/rel; digest=hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
 try:
  r=subprocess.run([str(python),'-c',code,str(p)],cwd=p.parent,env=env,capture_output=True,text=True,timeout=30)
  line=next((x for x in reversed(r.stdout.splitlines()) if x.startswith('RESULT:')),None)
  if line is None: outcome='unavailable'; error='no-result-marker:'+str(r.returncode)+':'+(r.stderr.splitlines()[-1][:180] if r.stderr.splitlines() else '')
  elif line=='RESULT:RETURNED': outcome='returned';error=None
  else: outcome='error';error=line.removeprefix('RESULT:ERROR:')
  allrows.append({'revision':'original','path':rel,'sha256':digest,'outcome':outcome,'error':error,'elapsed_seconds':round(time.monotonic()-start,3)})
 except subprocess.TimeoutExpired:
  allrows.append({'revision':'original','path':rel,'sha256':digest,'outcome':'timeout','error':None,'elapsed_seconds':30})
 (base/'runs.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in allrows))
print('original done',len(cases),flush=True)
