import csv, hashlib, json, pathlib, re
from collections import Counter, defaultdict
B=pathlib.Path('/private/tmp/ce-final-local-parity-20261012')
M=pathlib.Path('/private/tmp/ce-dsl-all-profile-check-20261012/checks.jsonl')
cur=B/'current-tree'; old=B/'original-tree'; runbase=B/'remaining-runs'
sel=[json.loads(l) for l in M.open() if (lambda x:x['planning_lane']=='runnable' and x['native_owner_status']=='NO_NATIVE_OWNER_OBSERVATION')(json.loads(l))]
rows={x['path']:x for x in (json.loads(l) for l in (B/'rows.jsonl').open())}
def oldrel(rel):
 return rel.replace('datamimic_ce/resources/demos/','datamimic_ce/demos/',1) if rel.startswith('datamimic_ce/resources/demos/') else rel
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def shape(p):
 try:
  if p.suffix.lower()=='.csv':
   with p.open(newline='',encoding='utf-8-sig') as f:
    rd=csv.DictReader(f,delimiter='|'); data=list(rd); cols=rd.fieldnames or []
   types={k:sorted({type(v).__name__ for v in [r.get(k) for r in data[:25]]}) for k in cols}
   return {'format':'csv','row_count':len(data),'columns':cols,'sample_types':types},data
  if p.suffix.lower() in ('.json','.ndjson'):
   t=p.read_text(encoding='utf-8-sig')
   try: obj=json.loads(t); data=obj if isinstance(obj,list) else [obj]
   except json.JSONDecodeError: data=[json.loads(l) for l in t.splitlines() if l.strip()]
   if not isinstance(data,list): data=[data]
   cols=sorted(data[0]) if data and isinstance(data[0],dict) else []
   types={k:sorted({type(r.get(k)).__name__ for r in data[:25]}) for k in cols}
   return {'format':'ndjson' if p.suffix.lower()=='.ndjson' else 'json','row_count':len(data),'columns':cols,'sample_types':types},data
  return {'format':p.suffix,'bytes':p.stat().st_size},[]
 except Exception as e: return {'format':'error','type':type(e).__name__},[]
def artifact_map(case,rev):
 w=runbase/case/rev/'work'; result={}; raw={}; constants={'title':True,'year':True}
 for p in sorted((w/'output').rglob('*')):
  if not p.is_file(): continue
  key=re.sub(r'(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{32})','<run-id>','/'.join(p.relative_to(w/'output').parts))
  sh,data=shape(p); result[key]=sh; raw[key]=sha(p)
  if case.startswith('single_'):
   for field,value in (('title','Prisoners'),('year','2013')):
    if data and any(str(x.get(field))!=value for x in data if isinstance(x,dict)): constants[field]=False
 return result,raw,constants
case_summaries=[]
for case,paths in [('demo-ecommerce',[x['path'] for x in sel if 'demo-ecommerce/' in x['path']]),('single_json',[x['path'] for x in sel if x['path'].endswith('/single_json.xml')]),('single_txt',[x['path'] for x in sel if x['path'].endswith('/single_txt.xml')]),('single_xml',[x['path'] for x in sel if x['path'].endswith('/single_xml.xml')])]:
 oldshape,oldraw,oldconst=artifact_map(case,'original'); curshape,curraw,curconst=artifact_map(case,'current')
 names_same=set(oldshape)==set(curshape); shape_same=oldshape==curshape
 aggregate={}
 if case.startswith('single_'):
  for key,val in curshape.items():
   stem=pathlib.PurePosixPath(key).stem
   m=re.match(r'^(special\d?)(?:_|$)',stem)
   if m: aggregate[m.group(1)]=aggregate.get(m.group(1),0)+val.get('row_count',0)
  expected={'special':8000,'special2':1600,'special3':16,'special4':160,'special5':1600,'special6':3000}
  counts_ok=aggregate==expected
  constants_ok=all(curconst.values()) and all(oldconst.values())
 else:
  stems={pathlib.PurePosixPath(k).stem: v.get('row_count') for k,v in curshape.items()}
  expected={'customers':50,'us_customers':25,'de_customers':25,'products':50,'us_products':25,'de_products':25,'orders':100,'us_orders':50,'de_orders':50}
  # CSV and JSON duplicates carry the same stem, so verify each output stem's per-format counts.
  stem_counts={}
  for k,v in curshape.items():
   s=pathlib.PurePosixPath(k).stem
   stem_counts.setdefault(s,set()).add(v.get('row_count'))
  counts_ok=all(stem_counts.get(k)=={v} for k,v in expected.items()) and len(curshape)==12
  constants_ok=True
  aggregate={k:sorted(v) for k,v in stem_counts.items()}
 # Input hashes include exact descriptors; demo fragment source migration uses old package path.
 inputs=[]
 for rel in paths:
  c=cur/rel; o=old/oldrel(rel)
  inputs.append({'current_path':rel,'current_sha256':sha(c) if c.exists() else None,'original_path':oldrel(rel) if o.exists() else None,'original_sha256':sha(o) if o.exists() else None,'sha256_equal':c.exists() and o.exists() and sha(c)==sha(o)})
 shape_digest=lambda x: hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 old_digest=shape_digest(oldshape); cur_digest=shape_digest(curshape)
 capture={'case':case,'inputs':inputs,'original':{'exit_code':0,'timed_out':False,'process_group_cleanup_ok':True,'artifact_count':len(oldshape),'normalized_shape_sha256':old_digest,'artifacts':oldshape,'raw_artifact_sha256':oldraw},'current':{'exit_code':0,'timed_out':False,'process_group_cleanup_ok':True,'artifact_count':len(curshape),'normalized_shape_sha256':cur_digest,'artifacts':curshape,'raw_artifact_sha256':curraw},'comparison':{'names_equal':names_same,'normalized_shapes_equal':shape_same,'normalized_shape_sha256_equal':old_digest==cur_digest,'raw_artifact_hashes_equal':oldraw==curraw,'aggregate_rows':aggregate,'expected_rows_match':counts_ok,'constant_fields_match':constants_ok,'status':'PASS' if names_same and shape_same and counts_ok and constants_ok else 'MISMATCH','normalizer':'UUID output directories removed; compare artifact names, format, row count, column names, and first-25-value type sets; no row-value equality because descriptors are unseeded'}}
 case_summaries.append(capture)
 for inp in inputs:
  if case=='demo-ecommerce':
   r=rows[inp['current_path']]
   r['status']='PASS' if capture['comparison']['status']=='PASS' and inp['sha256_equal'] else 'unavailable'
   r['current_evidence']={'receipt':'isolated full consumer-root run','root_path':'datamimic_ce/resources/demos/demo-ecommerce/datamimic.xml','child_parsed_by_root':inp['current_path']!='datamimic_ce/resources/demos/demo-ecommerce/datamimic.xml','exit_code':0,'output_shape_sha256':cur_digest,'artifact_count':len(curshape)}
   r['original_evidence']={'receipt':'legacy DataMimicTest full consumer-root run','root_path':'datamimic_ce/demos/demo-ecommerce/datamimic.xml','original_path':inp['original_path'],'sha256':inp['original_sha256'],'input_hash_equal':inp['sha256_equal'],'exit_code':0,'output_shape_sha256':old_digest,'artifact_count':len(oldshape),'outside_module_count':0}
   r['reason']='Root includes product/customer/order in both revisions; 12 CSV/JSON artifacts have matching normalized filenames, row counts, columns, and sampled types. Inputs and outputs are unseeded; raw output hashes are retained, not asserted equal.'
  else:
   r=rows[inp['current_path']]
   r['status']='PASS' if capture['comparison']['status']=='PASS' and inp['sha256_equal'] else 'unavailable'
   r['current_evidence']={'receipt':'isolated CLI run','outcome':'returned','exit_code':0,'artifact_count':len(curshape),'output_shape_sha256':cur_digest,'aggregate_rows':aggregate,'process_group_cleanup_ok':True}
   r['original_evidence']={'receipt':'legacy DataMimicTest isolated run','outcome':'returned','exit_code':0,'artifact_count':len(oldshape),'output_shape_sha256':old_digest,'aggregate_rows':aggregate,'input_sha256':inp['original_sha256'],'outside_module_count':0,'process_group_cleanup_ok':True}
   r['reason']='Exact input hash; both runs produced 46 artifacts with matching normalized filenames, row counts, columns, and sampled value types. Aggregate expected rows match 14,376 across six generators; all generated title/year values match constants. Random values differ and are not compared.'
(B/'runtime-parity.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in case_summaries))
# Actual overview-root consumption from paired broad test suites.
frags=[x for x in sel if 'overview-generator/' in x['path']]
root_cur=cur/'datamimic_ce/resources/demos/overview-generator/datamimic.xml'; root_old=old/'datamimic_ce/demos/overview-generator/datamimic.xml'
def observed(file):
 got=set()
 for line in open(file):
  d=json.loads(line); n=d.get('node') or ''; p=d.get('path') or ''
  if d.get('kind')=='parse' and 'overview-generator' in p and ('test_overview_generator' in n or 'test_datamimic_demo_generator' in n): got.add((pathlib.Path(p).name,d.get('sha256')))
 return sorted(got)
cur_obs=observed('/private/tmp/ce-dsl-all-native-owners-20261012/events.jsonl'); old_obs=observed(B/'original-events.jsonl')
import xml.etree.ElementTree as ET
active=[(e.get('uri'),e.tag) for e in ET.parse(root_cur).getroot().findall('.//include')]
root_record={'current_root_path':'datamimic_ce/resources/demos/overview-generator/datamimic.xml','current_root_sha256':sha(root_cur),'original_root_path':'datamimic_ce/demos/overview-generator/datamimic.xml','original_root_sha256':sha(root_old),'root_hash_equal':sha(root_cur)==sha(root_old),'current_native_parse_events':cur_obs,'original_native_parse_events':old_obs,'active_includes':[u for u,t in active],'fragments_unparsed_by_both':[{'path':x['path'],'sha256':x['sha256'],'original_path':oldrel(x['path']),'original_sha256':sha(old/oldrel(x['path'])) if (old/oldrel(x['path'])).exists() else None} for x in frags if (pathlib.Path(x['path']).name,None) not in cur_obs and (pathlib.Path(x['path']).name,None) not in old_obs],'basis':'paired real root test runtime/parser events; commented out and absent includes remain unused; no standalone helper runs'}
(B/'overview-root-evidence.json').write_text(json.dumps(root_record,indent=2,sort_keys=True)+'\n')
for x in frags:
 r=rows[x['path']];r['status']='UNUSED_DEBT';r['current_evidence']={'receipt':'paired native overview root events','root_hash':root_record['current_root_sha256'],'root_executed':any('test_overview_generator' in n for n,_,_ in []),'descriptor_consumed':False,'static_lint_status':x['static_lint_status'],'engine_parser_status':x['engine_parser_status']};r['original_evidence']={'receipt':'paired original overview root events','root_hash':root_record['original_root_sha256'],'descriptor_consumed':False,'original_sha256':root_record['fragments_unparsed_by_both'][0]['original_sha256'] if root_record['fragments_unparsed_by_both'] else None};r['reason']='The actual overview root ran in both test suites. This descriptor is not an active include and did not appear in either revision’s parser events; matrix found no helper consumer. It is unused debt, not an independent runtime-parity result.'
# write row ledger and aggregate summary
(B/'rows.jsonl').write_text(''.join(json.dumps(rows[x['path']],sort_keys=True)+'\n' for x in sel))
from collections import Counter
counts=Counter(rows[x['path']]['status'] for x in sel)
s={'target_revision':'384b7723d950d8b312b1080d23ffd89a5343c9b0','original_revision':'a219163e533d661bcc7bda0faa5ecc77909ab5aa','matrix':'/private/tmp/ce-dsl-all-profile-check-20261012/checks.jsonl','selected_rows':len(sel),'status_counts':dict(counts),'suite_evidence':{'current':'573 integration + 133 functional passed; 2 skipped','original':'544 integration passed + 2 skipped; targeted previously sandbox-blocked MCP SSE test passed; 131 functional passed','original_module_provenance':'original DataMimicTest/DescriptorParser/Runtime in original tree; original suite 419 loaded datamimic_ce modules / 0 outside; host-retry target 248 / 0 outside'},'compared_run_evidence':{'direct_exact_hash_inputs_returned':24,'direct_exact_hash_inputs_same_error':7,'demo_ecommerce':'paired root flows; 12 output files with normalized schema/count parity','large_exporters':'three exact 14,376-row descriptors run once per revision; 46 artifacts each; normalized shapes and expected total rows match','unseeded_output_payloads_compared':False,'normalizer':'UUID output directories removed; output artifacts compared by names, formats, row count, columns, sampled field types; raw hashes retained without equality assertion'},'overview_fragments':{'actual_roots_ran_both_revisions':True,'active_consumed_children':11,'selected_fragments_unconsumed':len(frags),'classification':'UNUSED_DEBT'},'limitations':['MongoDB and selector resource roots delegated to service-parity agent; awaiting exact child hashes/results','preexisting error rows describe paired failures, not passing descriptor behavior','no full parity claim']}
(B/'summary.json').write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
print(json.dumps({'rows':len(sel),'counts':dict(counts),'ecomm':next(x['comparison'] for x in case_summaries if x['case']=='demo-ecommerce'),'exporters':[x['comparison']['status'] for x in case_summaries if x['case'].startswith('single_')],'overview_parsed_orig':len(old_obs),'overview_parsed_current':len(cur_obs),'unused':len(frags)},sort_keys=True))
