import csv, hashlib, json, os, pathlib, shutil, subprocess, sys, time
sys.path.insert(0, "/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011")
from process_group_guard import wait_for_process_group
BASE=pathlib.Path("/private/tmp/ce-final-local-parity-20261012")
PYTHON="/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python"

CLI='/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/datamimic'
SOURCES={'current':BASE/'current-tree','original':BASE/'original-tree'}
CASES=[('demo-ecommerce','datamimic_ce/resources/demos/demo-ecommerce','datamimic.xml')]
for name in ('single_json','single_txt','single_xml'):
 CASES.append((name,'tests_ce/integration_tests/test_exporters',name+'.xml'))

def shape(path):
 try:
  if path.suffix.lower()=='.csv':
   with path.open(newline='',encoding='utf-8-sig') as f:
    r=csv.DictReader(f); rows=list(r); fields=r.fieldnames or []
   types={k:sorted({('null' if v is None else 'bool' if v.lower() in ('true','false') else 'int' if v.lstrip('-').isdigit() else 'float' if _isfloat(v) else 'string') for v in [x.get(k) for x in rows[:30]]}) for k in fields}
   return {'format':'csv','rows':len(rows),'columns':fields,'sample_types':types}
  if path.suffix.lower()=='.json':
   text=path.read_text(encoding='utf-8-sig')
   try: data=json.loads(text); rows=data if isinstance(data,list) else [data]
   except json.JSONDecodeError: rows=[json.loads(x) for x in text.splitlines() if x.strip()]
   if not isinstance(rows,list): rows=[rows]
   return {'format':'json','rows':len(rows),'top_type':type(data).__name__ if 'data' in locals() else 'jsonl','keys':sorted(rows[0]) if rows and isinstance(rows[0],dict) else None,'sample_types':{k:sorted({type(x.get(k)).__name__ for x in rows[:30]}) for k in rows[0]} if rows and isinstance(rows[0],dict) else None}
  if path.suffix.lower()=='.xml':
   import xml.etree.ElementTree as ET
   root=ET.parse(path).getroot(); return {'format':'xml','root':root.tag,'element_count':sum(1 for _ in root.iter())}
  return {'format':path.suffix or 'text','bytes':path.stat().st_size,'lines':sum(1 for _ in path.open(errors='replace'))}
 except Exception as e: return {'format':'unreadable','error':type(e).__name__}
def _isfloat(x):
 try: float(x); return True
 except (TypeError,ValueError): return False

def run(rev,name,subdir,filename):
 src=SOURCES[rev]; source_subdir=subdir.replace('datamimic_ce/resources/demos/','datamimic_ce/demos/',1) if rev=='original' and subdir.startswith('datamimic_ce/resources/demos/') else subdir; case_root=src/source_subdir; dest=BASE/'remaining-runs'/name/rev/'work'
 if dest.exists(): shutil.rmtree(dest)
 shutil.copytree(case_root,dest)
 descriptor=dest/filename
 before={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()}
 env=os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'; env['PYTHONPATH']=str(src)
 if rev=='current': cmd=[CLI,'run',str(descriptor)]
 else:
  code="import sys; from pathlib import Path; from datamimic_ce.data_mimic_test import DataMimicTest; p=Path(sys.argv[1]); DataMimicTest(test_dir=p.parent, filename=p.name).test_with_timer()"
  cmd=[PYTHON,'-c',code,str(descriptor)]
 start=time.monotonic(); p=subprocess.Popen(cmd,cwd=str(dest),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 try: output,_=p.communicate(timeout=240); timed=False
 except subprocess.TimeoutExpired:
  guard=wait_for_process_group(p,0.01); output,_=p.communicate(); timed=True
  if not guard.get('cleanup_ok'): raise RuntimeError(f'process cleanup failed {name}/{rev}: {guard}')
 # On normal process completion, verify no remaining group children.
 guard=wait_for_process_group(p,0.1)
 generated=[]
 for f in sorted(dest.rglob('*')):
  if f.is_file() and str(f.relative_to(dest)) not in before:
   b=f.read_bytes(); generated.append({'path':str(f.relative_to(dest)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'shape':shape(f)})
 short='\n'.join(output.splitlines()[-18:])[-1800:]
 return {'revision':rev,'case':name,'exit_code':p.returncode,'timed_out':timed,'elapsed_seconds':round(time.monotonic()-start,2),'cleanup':guard,'generated':generated,'log_tail':short}
rows=[]
for case in CASES:
 for rev in ('original','current'):
  row=run(rev,*case); rows.append(row)
  path=BASE/'remaining-runs.jsonl'; path.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
  print(case[0],rev,'exit',row['exit_code'],'timeout',row['timed_out'],'files',len(row['generated']),flush=True)
