import json, hashlib, pathlib, collections
B=pathlib.Path('/private/tmp/ce-final-local-parity-20261012')
cur_events=list(map(json.loads,open('/private/tmp/ce-dsl-all-native-owners-20261012/events.jsonl')))
old_events=list(map(json.loads,open(B/'original-events.jsonl')))
service=list(map(json.loads,open('/private/tmp/ce-final-service-parity-20261012/rows.jsonl')))
rows=list(map(json.loads,open(B/'rows.jsonl')))
# Promote 8 service rows by exact current path/hash.
svc={ (x['current_path'],x['current_sha256']):x for x in service if 'current_path' in x and 'current_sha256' in x and isinstance(x.get('evidence'),dict) }
for r in rows:
 if r['status']=='unavailable':
  x=svc.get((r['path'],r['sha256']))
  if x:
   r['status']='PASS'
   r['reason']='Paired native service-backed aggregate root run with independent DB readback; unseeded generated output bytes not compared.'
   r['current_evidence']={'junit':x['evidence']['current_junit'],'root_run':x['evidence']['current_suite'],'readback':'service-run/current-demo-readback.json'}
   r['original_evidence']={'junit':x['evidence']['old_junit'],'root_run':x['evidence']['old_suite'],'readback':'service-run/original-demo-readback.json'}
   r['service_readback']='Mongo CUSTOMER=0 after cleanup; selector collections=0 after cleanup; PostgreSQL ids 1..10 with Name id.'
# Pair final captured native cases.
final=list(map(json.loads,open(B/'final-cases.jsonl')))
for case in ('global_increment_script','empty_echo'):
 group=[x for x in final if x['case']==case]
 if case=='global_increment_script':
  assert len(group)==2 and all(x['exit_code']==0 and x['result']['contract']['bounded_counts'] and x['result']['outside']==[] for x in group)
  rows.append({'path':'tests_ce/integration_tests/test_global_increment_script/datamimic.xml','sha256':group[0]['input_sha256'],'original_path':'tests_ce/integration_tests/test_global_increment_script/datamimic.xml','original_sha256':group[0]['input_sha256'],'status':'PASS','reason':'Native test module executed once per revision; both captured outputs satisfy global sequential order/lineitem ID contract and bounded counts. Inputs identical; outputs unseeded, so output hashes intentionally differ and are not a parity criterion.','original_evidence':{'actual_test_module':'tests_ce/integration_tests/test_global_increment_script/test_global_increment_script.py','execution':'runpy under original API/source closure','result':group[0]['result']},'current_evidence':{'actual_test_module':'tests_ce/integration_tests/test_global_increment_script/test_global_increment_script.py','execution':'runpy under current API/source closure','result':group[1]['result']}})
 else:
  # Current successful native owner parse is exact current source hash.
  cur=[e for e in cur_events if e.get('kind')=='parse' and e.get('sha256')=='1ba872c51426732e4eb8ec40dd9a695218f295662b1ad867235e6cf2bf09069d']
  assert cur
  rows.append({'path':'tests_ce/integration_tests/test_echo/empty_echo.xml','sha256':'1ba872c51426732e4eb8ec40dd9a695218f295662b1ad867235e6cf2bf09069d','original_path':None,'original_sha256':None,'status':'APPROVED_CHANGE','reason':'Amendment 92 explicitly approves replacing old TypeError with empty diagnostic + continuation. Old actual legacy API run raised TypeError; current native test owner passed and current literal descriptor returned. This is intentional behavior change, not parity PASS.','approval_source':'docs/architecture/refactoring-study/experiment-2/amendment-92.md','original_evidence':{'literal_input_hash':'1ba872c51426732e4eb8ec40dd9a695218f295662b1ad867235e6cf2bf09069d','actual_api':'original-suite/datamimic_ce/data_mimic_test.py','outcome':'TypeError: expected string or bytes-like object, got NoneType','module_closure':'254 datamimic_ce modules, 0 outside frozen original-suite'},'current_evidence':{'native_owner':'tests_ce/integration_tests/test_echo/test_echo.py::TestEcho::test_empty_echo','parser_outcome':'returned','literal_hash_matches':True,'native_source_copy':'/private/tmp/ce-literal-source-arms-candidate-20261011/tests_ce/integration_tests/test_echo/empty_echo.xml'}})
# 9 XLSX path/hash copy correspondences from native test events, no reruns.
fixtures={
'read_complex_cyclic.xml':'4a0afbc7bcc9432bfa16b7f5325db86a30a743a451658f53f254ee7a923e6d6d',
'read_count_only.xml':'cb03c4d10235d3f532ddee18d514693b6363c347821ae84c7f5ffb3255007400',
'read_cumulated_seeded.xml':'f837ffc4ee3290886d010e4cb62bc2e43e7f872460ed0524916493cf62268a64',
'read_cyclic_paged.xml':'bdfdf867116b25432a131b9f5a32f8ef4bb2e8143dab5327745dc12b7a9901b4',
'read_paged_ordered.xml':'b2df68531e501d6205db5de4fd6468347adb0f2883e2a626404ff71ee586b04a',
'read_random_seeded.xml':'0b88b0ba9ba899e5cafe972bd15dfb5c4e87ea5892a8ae2e3b552e80b0ec3bba',
'read_random_unseeded.xml':'9b146b3927db77667d072fc9d3a7ac9637d2109309543206b23a7ad39706b262',
'read_xyz.xml':'86ead23b2529f53e43b0738fe987005c2822b1d7cfd9ca0b4fc6ce75a99b43ed',
'xlsx_read.xml':'9245ce894722cf6680c3ac7f5243a1bd7087aef6af592b7c6d8bafdc15a1f845',}
cor=[]
for name,digest in fixtures.items():
 def entries(ev):
  parses=[e for e in ev if e.get('kind')=='parse' and e.get('sha256')==digest]
  result=[]
  for e in parses:
   node=e.get('node')
   phases=[{'phase':p.get('phase'),'outcome':p.get('outcome')} for p in ev if p.get('kind')=='test_phase' and p.get('node')==node]
   result.append({'path':e.get('path'),'owner':node,'parse_outcome':e.get('outcome'),'phases':phases})
  return result
 old=entries(old_events); cur=entries(cur_events)
 assert old and cur,(name,len(old),len(cur))
 assert all(x['parse_outcome']=='returned' for x in old+cur)
 assert all(all(p['outcome']=='passed' for p in x['phases'] if p['phase']=='call') for x in old+cur)
 cor.append({'fixture':name,'sha256':digest,'status':'PASS','original':old,'current':cur,'copy_provenance':{'current_source':'tests_ce/integration_tests/test_xlsx_exporter/'+name,'current_source_sha256':digest,'mechanism':'tests_ce/integration_tests/test_xlsx_exporter/conftest.py copies each *.xml to tmp_path with shutil.copyfile before native owner execution','original_source':'tests_ce/integration_tests/test_xlsx_exporter/'+name,'original_exact_path_native':True,'hash_correspondence_confirmed':True},'reason':'Existing full native suites cover owner assertions; source/copy exact hash and parser/native owner phases correspond. No rerun needed.'})
(B/'xlsx-copy-correspondence.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in cor))
# Add closure evidence rows to unified path ledger (service promotions already applied).
rows.extend(cor)
(B/'rows.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
# Evidence record for the corrected old echo direct run.
(B/'approved-change-evidence.json').write_text(json.dumps({'path':'tests_ce/integration_tests/test_echo/empty_echo.xml','sha256':'1ba872c51426732e4eb8ec40dd9a695218f295662b1ad867235e6cf2bf09069d','original':{'outcome':'TypeError: expected string or bytes-like object, got NoneType','api':'/private/tmp/ce-final-local-parity-20261012/original-suite/datamimic_ce/data_mimic_test.py','module_count':254,'outside_modules':[]},'current':{'native_owner':'tests_ce/integration_tests/test_echo/test_echo.py::TestEcho::test_empty_echo','parser_outcome':'returned','source_sha256_matches':True},'classification':'APPROVED_CHANGE','amendment':'docs/architecture/refactoring-study/experiment-2/amendment-92.md'},indent=2)+'\n')
summary=json.load(open(B/'summary.json'))
counts=collections.Counter(r['status'] for r in rows)
summary['selected_rows']=57
summary['additional_closure_rows']=11
summary['path_level_rows']=len(rows)
summary['status_counts']=dict(counts)
summary['service_rows']='8 paired root/child descriptor receipts with readback from /private/tmp/ce-final-service-parity-20261012/rows.jsonl'
summary['final_cases']={'global_increment_script':'paired actual scenario runs; output contracts pass; unseeded outputs are not byte-compared','empty_echo':'APPROVED_CHANGE under Amendment 92; old legacy API TypeError observed, current native owner pass'}
summary['xlsx_copy_correspondence']={'fixtures':len(cor),'rerun':False,'evidence':'native original/current parser and test phases plus exact source/copy SHA-256'}
summary['limitations']=['preexisting error rows are matching failures, not successful descriptor behavior','unused fragments are excluded from runtime claims','approved empty-echo change is not parity evidence','unseeded output payloads are not compared byte-for-byte','no full parity claim']
summary['compared_run_evidence']['service_backed_demos']='8 exact raw MongoDB/selector paths covered by paired native aggregate-root runs plus independent DB readback'
summary['compared_run_evidence']['global_increment_script']='both revisions returned; global sequential-ID contract and bounded output shape passed; raw unseeded output bytes differ and were not compared'
summary['compared_run_evidence']['xlsx_copy_fixtures']='9 source descriptors mapped to current pytest tmp_path copies by exact hash; original/current native owner phases passed; no fixture rerun'
summary['compared_run_evidence']['empty_echo']='Amendment 92 approved behavior change; original legacy TypeError reproduced, current owner passes'
summary['unseeded_output_payloads_compared']=False
(B/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print('rows',len(rows),'counts',dict(counts),'xlsx',len(cor))
