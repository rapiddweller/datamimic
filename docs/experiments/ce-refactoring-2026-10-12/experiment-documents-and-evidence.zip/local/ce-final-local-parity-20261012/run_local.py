import hashlib, json, os, pathlib, shutil, subprocess, tarfile, time
BASE=pathlib.Path("/private/tmp/ce-final-local-parity-20261012")
CASES=json.loads((BASE/"case_paths.json").read_text())
SOURCES={"current":pathlib.Path("/Users/akell/PycharmProjects/development-v2/datamimic"),"original":pathlib.Path("/Users/akell/.codex/worktrees/ce-step0-descriptor-oracle/datamimic")}
PYTHON=pathlib.Path("/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python")
rows=[]
for label,source in SOURCES.items():
    archive=BASE/(label+".tar")
    root=BASE/(label+"-tree")
    root.mkdir(parents=True,exist_ok=True)
    with archive.open("wb") as stream:
        subprocess.run(["git","archive","--format=tar","HEAD"],cwd=source,stdout=stream,check=True)
    with tarfile.open(archive) as tf: tf.extractall(root)
    archive.unlink()
    env=os.environ.copy(); env.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE="1",PATH=str(PYTHON.parent)+":"+os.environ.get("PATH",""))
    for path in CASES:
        descriptor=root/path
        if not descriptor.exists():
            rows.append({"revision":label,"path":path,"outcome":"missing","sha256":None}); continue
        digest=hashlib.sha256(descriptor.read_bytes()).hexdigest()
        started=time.monotonic()
        try:
            result=subprocess.run([str(PYTHON.parent/"datamimic"),"run",str(descriptor)],cwd=root,env=env,capture_output=True,text=True,timeout=30)
            outcome="returned" if result.returncode==0 else "error"
            error=(result.stderr or result.stdout).strip().splitlines()[-1][:300] if outcome=="error" and (result.stderr or result.stdout).strip() else None
            rows.append({"revision":label,"path":path,"sha256":digest,"outcome":outcome,"returncode":result.returncode,"elapsed_seconds":round(time.monotonic()-started,3),"error":error})
        except subprocess.TimeoutExpired:
            rows.append({"revision":label,"path":path,"sha256":digest,"outcome":"timeout","elapsed_seconds":30})
    (BASE/"runs.jsonl").write_text("".join(json.dumps(r,sort_keys=True)+"\n" for r in rows))
    print(label, "done", sum(r["revision"]==label for r in rows))
(BASE/"runs.jsonl").write_text("".join(json.dumps(r,sort_keys=True)+"\n" for r in rows))
