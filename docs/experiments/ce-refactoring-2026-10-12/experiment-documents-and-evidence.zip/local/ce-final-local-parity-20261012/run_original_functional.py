import json,os,pathlib,subprocess,sys,time
spec=__import__('importlib.util').util.spec_from_file_location('guard','/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011/process_group_guard.py')
guard=__import__('importlib.util').util.module_from_spec(spec);spec.loader.exec_module(guard)
root=pathlib.Path('/private/tmp/ce-final-local-parity-20261012/original-suite'); packet=pathlib.Path('/private/tmp/ce-final-local-parity-20261012')
env=os.environ.copy();env.update(PATH='/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin:'+env['PATH'],PYTHONPATH=str(packet)+':'+str(root),PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-n0 -p no:rerunfailures -p original_observer --junitxml='+str(packet/'original-functional.xml'))
start=time.monotonic()
with (packet/'original-functional.log').open('wb') as log:
 proc=subprocess.Popen(['make','test-functional'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 result=guard.wait_for_process_group(proc,900)
result.update(elapsed_seconds=time.monotonic()-start)
(packet/'original-functional-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
