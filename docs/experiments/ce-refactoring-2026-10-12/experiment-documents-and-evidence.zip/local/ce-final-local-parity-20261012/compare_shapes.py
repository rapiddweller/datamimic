import csv,json,pathlib,re
base=pathlib.Path('/private/tmp/ce-final-local-parity-20261012/remaining-runs')
def shape(p):
 try:
  if p.suffix=='.csv':
   with p.open(newline='',encoding='utf-8-sig') as f:
    reader=csv.DictReader(f,delimiter='|'); rows=list(reader); fields=reader.fieldnames or []
   return ('csv',len(rows),tuple(fields))
  if p.suffix in ('.json','.ndjson'):
   t=p.read_text(encoding='utf-8-sig')
   try: x=json.loads(t); arr=x if isinstance(x,list) else [x]
   except json.JSONDecodeError: arr=[json.loads(l) for l in t.splitlines() if l.strip()]
   if not isinstance(arr,list): arr=[arr]
   keys=tuple(sorted(arr[0])) if arr and isinstance(arr[0],dict) else ()
   types=tuple((k,tuple(sorted({type(x.get(k)).__name__ for x in arr[:20]}))) for k in keys)
   return ('json',len(arr),keys,types)
  return (p.suffix,p.stat().st_size)
 except Exception as e: return ('error',type(e).__name__)
def get(case,rev):
 root=base/case/rev/'work'; items={}
 for p in (root/'output').rglob('*'):
  if p.is_file():
   rel=p.relative_to(root/'output').parts
   key=re.sub(r'(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{32})','<uuid>','/'.join(rel))
   items[key]=shape(p)
 return items
for case in ('demo-ecommerce','single_json','single_txt','single_xml'):
 o=get(case,'original');c=get(case,'current')
 print(case, 'old/new outputs',len(o),len(c),'names_equal',set(o)==set(c),'shape_equal',o==c)
