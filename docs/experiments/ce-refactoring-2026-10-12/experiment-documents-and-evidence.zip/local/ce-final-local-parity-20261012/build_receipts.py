import hashlib, json
from pathlib import Path
base=Path('/private/tmp/ce-final-local-parity-20261012')
out=base
matrix=Path('/private/tmp/ce-dsl-all-profile-check-20261012/checks.jsonl')
selected=[]
for line in matrix.open():
 d=json.loads(line)
 if d['planning_lane']=='runnable' and d['native_owner_status']=='NO_NATIVE_OWNER_OBSERVATION': selected.append(d)
current=base/'current-tree'; original=base/'original-tree'
cur_runs={}
for line in (base/'runs.jsonl').open():
 d=json.loads(line)
 if d.get('revision')=='current': cur_runs[d['path']]=d
old_runs={json.loads(line)['path']:json.loads(line) for line in (base/'legacy-direct.jsonl').open()}
service_fragments=('demo-ecommerce/','demo-mongodb/','demo-selector/')
rows=[]
for d in selected:
 rel=d['path']; sha=d['sha256']
 cp=current/rel
 if rel.startswith('datamimic_ce/resources/demos/'):
  oldrel=rel.replace('datamimic_ce/resources/demos/','datamimic_ce/demos/',1)
 else: oldrel=rel
 op=original/oldrel
 cursha=hashlib.sha256(cp.read_bytes()).hexdigest() if cp.exists() else None
 oldsha=hashlib.sha256(op.read_bytes()).hexdigest() if op.exists() else None
 row={'path':rel,'sha256':sha,'current_sha256':cursha,'original_path':oldrel if op.exists() else None,'original_sha256':oldsha,'status':'unavailable','current_evidence':None,'original_evidence':None,'reason':None}
 if cursha != sha: row['reason']='current extraction hash mismatch; no runtime claim'
 elif rel in cur_runs and rel in old_runs:
  c=cur_runs[rel]; o=old_runs[rel]
  samehash= c.get('sha256')==sha and o.get('sha256')==sha and oldsha==sha
  sameout=c['outcome']==o['outcome']
  row['current_evidence']={'receipt':'direct_cli','outcome':c['outcome'],'returncode':c.get('returncode'),'error':c.get('error')}
  row['original_evidence']={'receipt':'legacy_DataMimicTest','outcome':o['outcome'],'error':o.get('error'),'outside_module_count':o.get('outside_module_count'),'api_modules':o.get('api_modules')}
  if samehash and sameout:
   row['status']='PASS' if c['outcome']=='returned' else 'preexisting'
   row['reason']='Exact input hash; original legacy DataMimicTest and current CLI both returned.' if c['outcome']=='returned' else 'Exact input hash; both revisions raise the same domain/scope ValueError. This establishes preexisting error behavior, not a successful descriptor.'
  else: row['reason']='Runtime outcome or source hash differs; requires investigation.'
 elif rel.endswith('demo-clinical-trial/datamimic.xml'):
  row['status']='preexisting'
  row['current_evidence']={'receipt':'current_cli_run','outcome':'error','error':'ValueError: missing required generate count'}
  row['original_evidence']={'receipt':'legacy_DataMimicTest','outcome':'error','error':'ValueError: missing required generate count','outside_module_count':0,'api_modules':{'DataMimicTest':'original-tree/datamimic_ce/data_mimic_test.py','DescriptorParser':'original-tree/datamimic_ce/parsers/descriptor_parser.py','DataMimic':'original-tree/datamimic_ce/datamimic.py'}}
  row['reason']='Both revisions reject exact-hash descriptor because <generate> lacks count; helper execute script was not reached.'
 elif any(f in rel for f in service_fragments):
  row['reason']='Delegated to service-parity agent; not run locally. Awaiting its exact-path result.'
 elif 'overview-generator/' in rel:
  row['reason']='No standalone run: consuming overview root comments out this fragment. No real consumer evidence, and standalone helper execution would overstate parity.'
 elif 'test_exporters/single_' in rel:
  row['reason']='Skipped exact descriptor run because it emits 8,000 rows; bounded-runtime policy. Existing broad suite does not establish this exact input.'
 else:
  row['reason']='No exact runtime receipt in the supplied native event set; not run in this bounded local pass.'
 rows.append(row)
with (out/'rows.jsonl').open('w') as f:
 for row in rows: f.write(json.dumps(row,sort_keys=True)+'\n')
from collections import Counter
counts=Counter(r['status'] for r in rows)
summary={'target_revision':'384b7723d950d8b312b1080d23ffd89a5343c9b0','original_revision':'a219163e533d661bcc7bda0faa5ecc77909ab5aa','matrix':'/private/tmp/ce-dsl-all-profile-check-20261012/checks.jsonl','selected_rows':len(rows),'status_counts':dict(counts),'suite_evidence':{'current':'573 integration + 133 functional passed; 2 skipped','original':'544 integration passed, 2 skipped; the sole sandbox socket failure passed on targeted host retry; 131 functional passed','original_module_provenance':'original DataMimicTest/DescriptorParser/DataMimic paths in original snapshot; 419 loaded datamimic_ce modules, 0 outside modules in suite observer; direct legacy receipts also 0 outside modules'},'direct_comparison':{'matched_exact_path_hash_inputs':len([r for r in rows if r['current_evidence'] and r['original_evidence']]),'returned_both':sum(r['status']=='PASS' for r in rows),'same_expected_error':sum(r['status']=='preexisting' for r in rows),'output_bytes_compared':False,'reason':'No established normalizer for unseeded output; receipts compare parse/runtime outcome and errors only.'},'limitations':['service demo paths await delegated result','unused overview fragments intentionally not run standalone','three 8,000-row exporter descriptors not run','no full-parity claim']}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
receipt='''Local CE runtime/parity receipt\n\nCompared current `experiment/target-architecture-v2` at `384b7723d950d8b312b1080d23ffd89a5343c9b0` with original `a219163e533d661bcc7bda0faa5ecc77909ab5aa`. Source trees were extracted privately under `/private/tmp`; no repository files, fixtures, or contracts were changed.\n\nThe current native suite evidence is 573 integration and 133 functional tests passed, with 2 skipped. The original broad run had 544 integration tests passed and 2 skipped, plus one MCP SSE test blocked by sandbox socket permissions; that exact test passed on a host-permission retry. The original functional suite had 131 passed. Original observer provenance confirmed `DataMimicTest`, `DescriptorParser`, and `DataMimic` came from the original snapshot; the suite loaded 419 `datamimic_ce` modules, none outside that tree.\n\nThirty exact test descriptors have direct original/current executions with matching input hashes. Both revisions returned for 24; both raised matching expected `ValueError` behavior for six unsupported-entity/scope cases. These are execution-outcome comparisons only. Generated output bytes were not compared because outputs are unseeded and no normalizer is established. The clinical-trial descriptor has a matching original/current rejection because `<generate>` lacks `count`; the included helper was not reached.\n\nThe overview-generator fragments are commented out in the consumer root and were not run standalone. Three single-exporter descriptors were skipped because they emit 8,000 rows. E-commerce, MongoDB, and selector demo resource descriptors are delegated to the service-parity agent and are pending its exact-path results.\n\nThe 57-row source/hash ledger is `rows.jsonl`; aggregate counts and revisions are in `summary.json`. This is partial local evidence, not a full parity claim.\n'''
(out/'receipt.md').write_text(receipt)
print(json.dumps({'rows':len(rows),'status_counts':dict(counts),'summary':str(out/'summary.json')},sort_keys=True))
