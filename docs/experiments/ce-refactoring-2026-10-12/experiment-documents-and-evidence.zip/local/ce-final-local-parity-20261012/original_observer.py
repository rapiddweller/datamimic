import functools,hashlib,json,os,uuid
from pathlib import Path
from datamimic_ce.parsers.descriptor_parser import DescriptorParser
from datamimic_ce.datamimic import DataMimic
PACKET=Path('/private/tmp/ce-final-local-parity-20261012')
node=None; session=None
orig_parse=DescriptorParser.parse
orig_run=DataMimic.parse_and_execute

def emit(kind,**values):
 event=dict(kind=kind,pid=os.getpid(),node=node,session=session,**values)
 fd=os.open(PACKET/'original-events.jsonl',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
 try: os.write(fd,(json.dumps(event,sort_keys=True)+'\n').encode())
 finally: os.close(fd)

@functools.wraps(orig_parse)
def parse(path,*args,**kwargs):
 p=Path(path).resolve()
 try: digest=hashlib.sha256(p.read_bytes()).hexdigest()
 except OSError: digest=None
 try: result=orig_parse(path,*args,**kwargs)
 except BaseException as e:
  emit('parse',path=str(p),sha256=digest,outcome='failed',error=type(e).__name__);raise
 emit('parse',path=str(p),sha256=digest,outcome='returned')
 return result

def run(self,*args,**kwargs):
 global session
 previous=session;session=str(uuid.uuid4())
 emit('runtime_start',path=str(self._descriptor_path.resolve()))
 try: result=orig_run(self,*args,**kwargs)
 except BaseException as e:
  emit('runtime_end',outcome='failed',error=type(e).__name__);raise
 else:
  emit('runtime_end',outcome='returned');return result
 finally: session=previous

def pytest_configure(config):
 DescriptorParser.parse=staticmethod(parse);DataMimic.parse_and_execute=run
 emit('observer_started')

def pytest_runtest_protocol(item,nextitem):
 global node
 node=item.nodeid
 try: yield
 finally: node=None

import pytest
pytest.hookimpl(hookwrapper=True)(pytest_runtest_protocol)

def pytest_runtest_logreport(report):
 emit('test_phase',test=report.nodeid,phase=report.when,outcome=report.outcome)

def pytest_sessionfinish(session, exitstatus):
 import inspect,sys
 from datamimic_ce.data_mimic_test import DataMimicTest
 root=Path('/private/tmp/ce-final-local-parity-20261012/original-suite').resolve()
 outside=[];loaded=0
 for name,module in tuple(sys.modules.items()):
  if not name.startswith('datamimic_ce') or module is None: continue
  origin=getattr(module,'__file__',None)
  if not origin: continue
  loaded+=1
  try: Path(origin).resolve().relative_to(root)
  except ValueError: outside.append(name)
 emit('module_provenance',loaded_datamimic_modules=loaded,outside_module_names=outside,
      data_mimic_test=inspect.getfile(DataMimicTest),descriptor_parser=inspect.getfile(DescriptorParser),
      runtime=inspect.getfile(DataMimic),exitstatus=exitstatus)
