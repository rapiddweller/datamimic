import hashlib,json,os,pathlib,re,runpy,shutil,subprocess,sys,time
sys.path.insert(0,'/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011')
from process_group_guard import wait_for_process_group
B=pathlib.Path('/private/tmp/ce-final-local-parity-20261012'); P='/Users/akell/PycharmProjects/development-v2/datamimic/.venv/bin/python'
S={'current':B/'current-tree','original':B/'original-tree'}

def execute(rev,case,source_subdir,script_rel,mode):
 src=S[rev]; d=B/'final-cases'/case/rev/'work'
 if d.exists(): shutil.rmtree(d)
 shutil.copytree(src/source_subdir,d)
 desc=d/'datamimic.xml' if mode=='increment' else d/'empty_echo.xml'
 if mode=='increment':
  code=r'''import runpy,sys,json,hashlib,inspect
from pathlib import Path
root=Path(sys.argv[1]).resolve(); script=Path(sys.argv[2]).resolve()
runpy.run_path(str(script),run_name='__main__')
out=[]
for n,m in tuple(sys.modules.items()):
 if n.startswith('datamimic_ce') and getattr(m,'__file__',None):
  try: Path(m.__file__).resolve().relative_to(root)
  except ValueError: out.append({'name':n,'file':str(Path(m.__file__).resolve())})
print('MODULE_ORIGIN:'+json.dumps({'loaded':sum(1 for n,m in sys.modules.items() if n.startswith('datamimic_ce') and getattr(m,'__file__',None)),'outside':out}))
'''
  cmd=[P,'-c',code,str(src),str(d/script_rel)]
  inp=hashlib.sha256((src/source_subdir/'datamimic.xml').read_bytes()).hexdigest()
 else:
  code=r'''import sys,json
from pathlib import Path
root=Path(sys.argv[1]).resolve(); p=Path(sys.argv[2]).resolve()
if sys.argv[3]=='current':
 from datamimic_ce.interfaces.python.data_mimic_test import DataMimicTest
else:
 from datamimic_ce.data_mimic_test import DataMimicTest
try:
 DataMimicTest(test_dir=p.parent,filename=p.name).test_with_timer(); outcome='returned'; error=None
except BaseException as e:
 outcome='error'; error=type(e).__name__+':'+str(e).splitlines()[0]
out=[]
for n,m in tuple(sys.modules.items()):
 if n.startswith('datamimic_ce') and getattr(m,'__file__',None):
  try: Path(m.__file__).resolve().relative_to(root)
  except ValueError: out.append({'name':n,'file':str(Path(m.__file__).resolve())})
print('CASE_RESULT:'+json.dumps({'outcome':outcome,'error':error,'loaded':sum(1 for n,m in sys.modules.items() if n.startswith('datamimic_ce') and getattr(m,'__file__',None)),'outside':out}))
if outcome=='error': sys.exit(2)
'''
  cmd=[P,'-c',code,str(src),str(desc),rev]
  inp=hashlib.sha256((S['current']/'tests_ce/integration_tests/test_echo/empty_echo.xml').read_bytes()).hexdigest()
 env=os.environ.copy();env.update(PYTHONPATH=str(src),PYTHONDONTWRITEBYTECODE='1')
 start=time.monotonic(); p=subprocess.Popen(cmd,cwd=d,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 try: output,_=p.communicate(timeout=180); timed=False
 except subprocess.TimeoutExpired:
  guard=wait_for_process_group(p,0.01);output,_=p.communicate();timed=True
  if not guard.get('cleanup_ok'): raise RuntimeError(f'cleanup failed {case}/{rev}')
 guard=wait_for_process_group(p,0.1)
 marker_name='MODULE_ORIGIN:' if mode=='increment' else 'CASE_RESULT:'
 marker=next((json.loads(l[len(marker_name):]) for l in output.splitlines() if l.startswith(marker_name)),None)
 if mode=='increment':
  idlines=[]
  for line in output.splitlines():
   m=re.fullmatch(r'oId:(O\d+)_lId:(L\d+)',line.strip())
   if m: idlines.append((int(m.group(1)[1:]),int(m.group(2)[1:])))
  orders=[]
  for oid,_ in idlines:
   if not orders or orders[-1]!=oid: orders.append(oid)
  lid=[x[1] for x in idlines]
  contract={'captured_lines':len(idlines),'orders':len(orders),'order_ids_sequential':orders==list(range(1,len(orders)+1)),'lineitem_ids_sequential':lid==list(range(1,len(lid)+1)),'order_line_items_grouped':all(a<=b for a,b in zip([x[0] for x in idlines],[x[0] for x in idlines][1:])),'bounded_counts':1<=len(orders)<=40 and len(orders)<=len(lid)<=20*len(orders)}
  marker={**(marker or {}),'contract':contract,'output_sha256':hashlib.sha256('\n'.join(f'oId:O{o}_lId:L{l}' for o,l in idlines).encode()).hexdigest(),'captured_only_ids':True}
 return {'case':case,'revision':rev,'input_sha256':inp,'exit_code':p.returncode,'timed_out':timed,'elapsed_seconds':round(time.monotonic()-start,2),'cleanup':guard,'result':marker,'log_tail':'\n'.join(output.splitlines()[-6:])[-1000:]}
rows=[]
for rev in ('original','current'):
 rows.append(execute(rev,'global_increment_script','tests_ce/integration_tests/test_global_increment_script','test_global_increment_script.py','increment'))
 rows.append(execute(rev,'empty_echo','tests_ce/integration_tests/test_echo','empty_echo.xml','echo'))
(B/'final-cases.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
print(json.dumps([{k:v for k,v in x.items() if k!='log_tail'} for x in rows],sort_keys=True))
