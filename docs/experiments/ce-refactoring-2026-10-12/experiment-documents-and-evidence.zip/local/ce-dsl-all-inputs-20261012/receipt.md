# All retained CE inputs — static native lint

LOCAL VERIFIED:931unique ledger paths inspected exactly once, sorted checks.jsonl. LedgerSHA91c35d062d31fca2433fe3424355c720639e2063c478dd644853fb5afd262ac2; SourceHEAD384b7723d950d8b312b1080d23ffd89a5343c9b0; candidate import origin verified. All files exist; all931hashes match retained c992 hashes. Single process,0.47s scan; checkout clean.

Results:914setup roots (788no phase-one errors,126with errors),16non-setup inputs (9list,3dataset,2namespaced course,1CodeList,1generate fragment),1XML-load rejection: existing authoring fixture fx_xml_syntax.xml. NO_PHASE1_ERRORS is not engine-parser/runtimePASS. Setup roots may be include fragments. Historical lanes/context retained per row.

Error rows by historical lane:45runnable,39external-service,21intentionally-invalid,21authoring-fixture,1non-descriptor. Summary groups every code/title and occurrence. Recurring DM103unknownattribute189, DM211selector count179, DM401unknowntarget161, DM402unknownsource199. Occurrences are not distinct failing profiles. Include/property/client context can explain standalone findings; no new runtime defect inferred.

Reused native secure XML load and existing linter _run_rules, unchanged schema/ALL_RULES. Phase2run_engine_parse omitted: it resolves real conf credentials at parse time and may embed engine/Pydantic payloads. No DescriptorParser/runtime/client creation, setup SQL, dry-run or generation. Only diagnostic rule/severity counts stored; no messages/raw attributes/credentials/error payloads. Local include/source/template/scriptFile paths inventoried; remote references redacted and expressions unresolved.29missing local references are potential context/fixture gaps, not proven runtime failures. Dependencies not recursively loaded/executed.

Controls: valid setup0errors; conflicting key sources nativeDM202/DM203; non-descriptor book separated.931rows/unique paths/pin/import origin/SourceHEAD selfchecks passed. Native code/check.py hashes in summary. No new framework or per-input essays.

Runtime parity remains UNKNOWN; no180/751ledger promotions. This completes all-input static/native-phase1 checking only. No newly reproduced anomaly demonstrated; no issue proposed.

CI-ONLY VERIFICATION: no new CI/runtime suite run. Ordinary owner execution and receipt joining remain separate work.
