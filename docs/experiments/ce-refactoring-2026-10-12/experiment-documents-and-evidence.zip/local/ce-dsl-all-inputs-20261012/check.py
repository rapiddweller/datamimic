"""One native phase-one lint pass; no runtime parser or descriptor execution."""
import hashlib
import json
import logging
import subprocess
import time
from collections import Counter
from pathlib import Path

import datamimic_ce
from datamimic_ce.authoring.adapters.linter import _run_rules
from datamimic_ce.authoring.adapters.xml_loader import load_file, load_source

ROOT = Path('/private/tmp/ce-literal-source-arms-candidate-20261011')
OUT = Path('/private/tmp/ce-dsl-all-inputs-20261012')
LEDGER = Path('/private/tmp/ce-step210-ledger.jsonl')
PIN = '91c35d062d31fca2433fe3424355c720639e2063c478dd644853fb5afd262ac2'
assert hashlib.sha256(LEDGER.read_bytes()).hexdigest() == PIN
manifest = [json.loads(line) for line in LEDGER.read_text().splitlines()]
assert len(manifest) == len({row['path'] for row in manifest}) == 931
origin = Path(datamimic_ce.__file__).resolve()
assert origin.is_relative_to(ROOT)
logging.disable(logging.CRITICAL)


def diagnostics(root, parent):
    records = _run_rules(root, parent)
    return dict(sorted(Counter(str(d.rule) for d in records).items())), dict(
        sorted(Counter(d.severity.value for d in records).items())
    )


def dependencies(root, parent):
    entries = []
    for element in root.iter():
        if not isinstance(element.tag, str):
            continue
        tag = element.tag.rsplit('}', 1)[-1]
        for key in ('uri', 'source', 'template', 'scriptFile'):
            value = element.get(key)
            if not value:
                continue
            if '://' in value or '@' in value:
                entries.append({'element': tag, 'attribute': key, 'kind': 'remote_redacted'})
                continue
            if any(char in value for char in ('{', '}', '$', '\n')):
                entries.append({'element': tag, 'attribute': key, 'kind': 'expression_unresolved'})
                continue
            path = Path(value)
            if not path.suffix and '/' not in value and '\\' not in value:
                entries.append({'element': tag, 'attribute': key, 'kind': 'logical_reference'})
                continue
            candidate = path if path.is_absolute() else parent / path
            entries.append({'element': tag, 'attribute': key, 'kind': 'local_path',
                            'path': value, 'exists': candidate.is_file()})
    return entries


controls = {}
for name, xml in [('valid', '<setup><generate name="g" count="1"><key name="x" constant="ok"/></generate></setup>'),
                  ('invalid', '<setup><generate name="g"><key name="x" constant="a" values="b"/></generate></setup>'),
                  ('non_descriptor', '<book><title>fixture</title></book>')]:
    root, error = load_source(xml)
    assert root is not None and error is None
    codes, levels = diagnostics(root, None) if root.tag == 'setup' else ({}, {})
    controls[name] = {'root': root.tag, 'codes': codes, 'severity': levels}
assert not controls['valid']['severity'].get('error', 0)
assert controls['invalid']['severity'].get('error', 0)
assert controls['non_descriptor']['root'] != 'setup'
started = time.monotonic()
rows = []
for item in sorted(manifest, key=lambda row: row['path']):
    path = ROOT / item['path']
    row = {'path': item['path'], 'exists': path.is_file(), 'planning_lane': item['planning_lane'],
           'historical_inventory_tags': item['current_inventory_categories'],
           'lint_scope': 'NATIVE_PHASE1_ONLY_NO_ENGINE_PARSE_OR_RUNTIME'}
    if not path.is_file():
        row.update(classification='missing', native_lint_status='NOT_LOADED')
    else:
        row['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        row['matches_historical_c992_hash'] = row['sha256'] == item.get('current_c992', {}).get('xml_sha256')
        root, error = load_file(path)
        row['well_formed'] = root is not None
        if root is None:
            row.update(classification='xml_load_rejected', native_lint_status='LOAD_DIAGNOSTIC',
                       diagnostic_codes={error.rule: 1} if error else {}, diagnostic_severity={'error': 1})
        else:
            row['xml_root'] = root.tag if isinstance(root.tag, str) else 'NON_ELEMENT'
            row['service_client_declared'] = any(e.tag in ('database', 'mongodb', 'kafka') for e in root.iter())
            row['declared_dependencies'] = dependencies(root, path.parent)
            if row['xml_root'] != 'setup':
                row.update(classification='non_setup_data_template_or_fragment', native_lint_status='NOT_DESCRIPTOR',
                           diagnostic_codes={}, diagnostic_severity={})
            else:
                codes, levels = diagnostics(root, path.parent)
                row.update(classification='setup_descriptor_or_include_fragment', native_lint_status='ERROR' if levels.get('error') else 'NO_PHASE1_ERRORS',
                           diagnostic_codes=codes, diagnostic_severity=levels)
    rows.append(row)
assert len(rows) == len({row['path'] for row in rows}) == 931
(OUT / 'checks.jsonl').write_text(''.join(json.dumps(row, sort_keys=True) + '\n' for row in rows))
summary = {'source_head': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
           'import_origin': str(origin), 'ledger_sha256': PIN, 'rows': len(rows),
           'unique_paths': len({r['path'] for r in rows}), 'elapsed_seconds': time.monotonic() - started,
           'classifications': dict(Counter(r['classification'] for r in rows)),
           'lint_status': dict(Counter(r['native_lint_status'] for r in rows)),
           'diagnostic_occurrences': dict(sum((Counter(r.get('diagnostic_codes', {})) for r in rows), Counter())),
           'controls': controls, 'runtime_executed': False, 'ledger_promoted': False,
           'local_dependency_references_missing': sum(not d['exists'] for r in rows for d in r.get('declared_dependencies', []) if d['kind'] == 'local_path'),
           'checks_sha256': hashlib.sha256((OUT / 'checks.jsonl').read_bytes()).hexdigest()}
assert summary['source_head'] == '384b7723d950d8b312b1080d23ffd89a5343c9b0'
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary, sort_keys=True))
