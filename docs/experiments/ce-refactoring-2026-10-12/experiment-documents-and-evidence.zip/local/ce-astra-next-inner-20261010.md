# Astra decision — Runtime lifecycle

CE `72202ba02f99e31e737b852043e32822a2e7d4f7`; read-only static review, 2026-10-10. Paths below are relative to `/Users/akell/PycharmProjects/development-v2/datamimic`, except EE paths, relative to its adjacent `datamimic-ee` checkout.

**Decision: KEEP the three-module RUNTIME-LIFECYCLE leaf. Correct only its cleanup ownership sentence. No new component, wrapper, source move, signature or behavior change is justified.**

## Why this cohort

The historical semantic review already proposed KEEP for lifecycle (`docs/architecture/inner/semantic-review/review-execution_io.json:697–731,1682,2342`). This is not a newly discovered folder. Those entries support the original target; `docs/architecture/inner/target.md:22–27` explicitly says current responsibility sentences are not individually accepted. Step 08C7 proves the earlier execution-boundary migration; later capture/property/log tests cover selected contracts. Neither is current whole-leaf responsibility acceptance. Step 189 accepts VALUES-CONSTRUCTION, not lifecycle. This review closes the latter bounded semantic obligation, not a second implementation slice or full behavioral acceptance.

## Complete operation trace

All three files are under `datamimic_ce/engine/runtime/lifecycle/`.

| Owner / operation | Caller → state / IO → observable result |
|---|---|
| `__init__.py` | Empty initializer; no state, IO or extra responsibility. Keep visible. |
| `config.py:15–29` | `runner.execute:65` and `runtime/api.py:23` → lazy cached `Settings`, process environment, native Pydantic validation → environment/page-size/edition/Ray settings. No configured dotenv file here. Preserve one cached instance and resolution timing. |
| `runner.py:23–40,105–110` | Runtime API `api.py:36–41` → session constructor stores the exact request, chooses task ID, process title, logging/system observations, a new capture exporter, then checks descriptor existence → session or native invalid-path ValueError. Module import sets `RAY_DEDUP_LOGS` before task imports (`runner.py:9–10`). Preserve ordering and side effects. |
| `runner.py:42–77` | `execute` → DSL parser receives original properties, current environment and IO-owned profile loader; optional factory selection mutates count/targets, then optional statement transformer → prepared SetupStatement or native error. DSL owns parsing/lookup; `engine/io/connection_config/properties.py:12` owns profile reads/fallback. Factory policy belongs here, not in a connector or transport. |
| `runner.py:79–97` | Session → `SetupTask(...).execute()` → new root Context/MemstoreManager and seeded state (`tasks/setup/setup_task.py:36,51–80`), task dispatch → RunResult with live capture in test mode, otherwise None. Preserve same property/capture objects and ValueError vs other-error logging/rethrow (`runner.py:90–95`). Settings resolution remains before the try. |
| `runner.py:99–102` | Python DataMimic/test/factory adapters → existing TestResultExporter storage → same mutable capture dict, including before execution and accumulated repeated runs; non-test call raises existing ValueError. Exporter `engine/io/exporters/diagnostics/test_result_exporter.py:18–38` appends native rows and returns storage, not a copy. |

Immediate consumers: `interfaces/python/datamimic.py:44,59–64`, `data_mimic_test.py:30`, `factory.py:32–59,74–103`; the public Runtime API forwards to this owner. Factory custom-data overlay stays in its existing adapter after capture/count assertions; do not absorb it into lifecycle. The request/result/session contracts remain `engine/runtime/contracts.py:40–65`.

Cleanup is owned at a different lifetime: `tasks/generate/task.py:344–368` captures/finalizes/publishes at the outer generation boundary and uses `finally` for chunk cleanup and conditional Ray shutdown. Actual chunk deletion is `engine/io/exporters/lifecycle.py:45`. CE runner has no run-final cleanup operation. Moving cleanup outward could change repeated generation, failures and resource timing.

## Exact declaration correction

At `docs/architecture/inner/runtime/architecture-contract.json:307`, replace:

> Run configuration, session/run orchestration and cleanup.

with:

> Own run configuration and session orchestration, including descriptor parsing, setup execution and test-result capture.

Keep packages, public operations, requires, rules and module declarations unchanged. The modules already declare their real responsibilities; this corrects the component's extra cleanup claim. Record the generation/IO cleanup boundary in the dated decision/amendment, preserving agent provenance. It is a statement about CE ownership, not permission to drop cleanup.

CE/EE alignment remains meaningful: `edition-alignment.md:27,37,50–53` places invocation/settings at Runtime and preserves edition-specific lifetimes. EE `datamimic_ee/lifecycle/execution_session.py:83–172` additionally owns run-level evidence-before-final-cleanup; `entrypoint.py:21–54` shuts down logging; CE has neither EE workspace/Redis cleanup nor that logger lifecycle. Shared target `target.md:87` may retain its edition-wide cleanup slot, but the acceptance note must distinguish CE's generation cleanup from EE's session cleanup. Do not copy EE machinery into CE or reinterpret this as identical behavior.

## Rechecked 13 violations: no faithful source repair identified

Decoded the native packet `/tmp/ce-step188-root-20261010/after.json`; all 13 remain violations, not accepted passes. Its reviewed source remains applicable to this documentation-only head.

| Findings | Current source / reason to retain |
|---|---|
| 4 PreparedPage positions (`04e977`, `278dfc`, `b07110`, `b59d6a`) | `engine/io/exporters/session.py:33–35,73–98`: existing tuple carries native JSON product plus XML rows; preparation/dispatch preserve shape, row identity and parent-validation timing. Known alias observer issue #438. No DTO wrapper or changed annotation spelling. |
| 3 GroupMask alternatives (`06a32e`, `215c23`, `94fd09`) | `domains/shared/demographics/sampler.py:28,331–334`: explicit union of three dictionary key families; returns a dict copy of the selected mask. Known alias observer issue #439. No cast or narrowed key family. |
| 3 variable/query/nested native results (`5f2114`, `a7cb8a`, `e960f3`) | `engine/io/data_sources/variable.py:21–87`, `router.py:179–216`: file/database/Memstore routes preserve native values and selection. JSON lists can contain scalars (`files/readers.py:283–301`; `tests_ce/unit_tests/test_io_files.py:32`); injected/native client and Memstore values are not established as closed JSON. A closed row DTO or JsonValue-only contract would assert an unproved restriction. |
| 1 GenerateFileSource rows (`e19f8e`) | `data_sources/boundary/models.py:23–25`, `router.py:106–139`: XML cached dictionary keys/values remain native. `tests_ce/unit_tests/test_io_files.py:46–85` explicitly preserves an integer key and object sentinel identity and native invalid-cache error. `dict[str, object]` would be false here. |
| 1 generator cache (`c40b83`) | `runtime/contexts/context.py:201,241`; `tasks/values/construction/factory.py:110–145`: supplied cache aliases nonempty caller state and stores/returns heterogeneous dynamically constructed generators. No common closed generator signature was established. Do not replace the cache with a nominal wrapper or narrow away injected behavior. |
| 1 SQL cast (`312396`) | `tasks/flow/commands/execute_task.py:57–70`; Amendment 155 requires injected `execute_sql_script(query)` implementations and native direct-call failures. Removing this finding by concrete-client narrowing, preflight reflection or moving the cast would violate that decision. |

Issues #440–441 concern additional observation limitations, not new safe repairs among these 13. The alias diagnoses are carried from the established issue/evidence mapping; this review did not claim newly published fixes or perform remote issue verification.

## Acceptance and next action

**One actionable recommendation:** accept this bounded lifecycle ownership decision and apply the single CE responsibility correction with provenance. Use the existing definition/report workflow; retain RED if the same 19 usage-UNKNOWN diagnostics block native amendment binding. Do not change source to make that binding succeed.

FACT: the coherent leaf and its actual request→state/IO→result ownership were inspected. Existing tests cover capture identity/repetition, environment/properties/log forwarding (`test_python_api/test_runtime_boundary.py:272–844`) and factory lookup/mutations (`test_runtime_factory_lookup.py:25–110`); read, not run here.

UNKNOWN: complete lifecycle parity, all error/cleanup paths, cold workers and concurrency were not established by this review. Keep the 13 violations, 254 canonical UNKNOWNs, pending report binding and remaining component semantic acceptance visible. This does not promote the frozen behavioral oracle or full protocol items 1–9; Step 190 public scope-message proof is separate.

LOCAL VERIFIED: read-only source/caller/test inspection and native finding decoding at the stated head. CI-ONLY VERIFICATION: none performed or inferred. No runtime execution or primary edits.
