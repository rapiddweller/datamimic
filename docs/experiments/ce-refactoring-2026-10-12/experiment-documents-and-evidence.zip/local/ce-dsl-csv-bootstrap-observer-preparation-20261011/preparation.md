# Bootstrap observer — preparation only

No control, native thread, Pool, CE owner, subprocess or runtime guard was executed. New packet contains only a candidate helper, minimal diff and this preparation note. Retained packets and ledger unchanged.

Extension: bounded 64 scalar records, 16 errors and 16 cached targets; native start caches target identity before run deletion; exact code/globals/pinned source bootstrap audit identifies expected callback from native globals; first real profiler event is recorded as received (no retrospective call); join distinguishes caller and joined object, timeout and native _is_stopped completion observation. In-memory rows retain writer-failed events with scalar exception types. Existing profile logic, delivery, effect/spawn guards and hook paths remain unchanged after the extra passive calls.

Existing retained control proof is inherited evidence, not proof of new observations:
- /private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011/taskdelivery-controls.json
- /private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011/thread-pool-only-taskdelivery-controls.json
- /private/tmp/ce-dsl-csv-thread-pytest-context-repair-20261011/outcome-report.md

Proposed control review before separate execution GO: reuse separately admitted CE-free native-thread context and existing real-frame controls; assert actual first-event kind rather than replaying bootstrap call, target retained after deletion, join timeout versus completed join, exact-type unsupported traps, wrong code/globals/source exclusions, 64-record saturation, recorder write failure retained in memory. No new Pool or spawn admission. Control adaptation and its admission remain pending.

UNKNOWN: new observer runtime correctness, interleaving/overhead, recorder-failure terminal persistence, prior task-thread cause, join identity and current/whole runtime parity. A missing receipt is never completion/death proof. The new in-memory error receipt must be retained by the existing terminal path; timeout persistence requires review before native admission.

LOCAL VERIFIED: syntax AST parsing only; no controls run. CI-ONLY VERIFICATION: none.
