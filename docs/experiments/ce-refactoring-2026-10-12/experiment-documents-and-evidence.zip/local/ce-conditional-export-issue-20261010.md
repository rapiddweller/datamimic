A nested `<generate>` inside `<condition><if>` logs that it generated and exported three records, but produces no final JSON files. The same child directly inside its parent publishes both chunks successfully.

Reproduced at `72202ba02f99e31e737b852043e32822a2e7d4f7` with the [existing native engine test](https://github.com/rapiddweller/datamimic/blob/72202ba02f99e31e737b852043e32822a2e7d4f7/tests_ce/unit_tests/test_generate_export_lifecycle.py#L127). The conditional case is already marked [strict xfail](https://github.com/rapiddweller/datamimic/blob/72202ba02f99e31e737b852043e32822a2e7d4f7/tests_ce/unit_tests/test_generate_export_lifecycle.py#L121); `--runxfail` exposes the real failed assertion.

```xml
<setup multiprocessing="0">
  <generate name="parents" count="1" target="">
    <key name="id" generator="IncrementGenerator"/>
    <condition><if condition="True">
      <generate name="children" count="3" target="JSON(chunk_size=2)" exportUri="results">
        <key name="id" generator="IncrementGenerator"/>
      </generate>
    </if></condition>
  </generate>
</setup>
```

Reproduce the two cases without changing the test:

```sh
.venv/bin/python -m pytest -p no:rerunfailures -q \
  tests_ce/unit_tests/test_generate_export_lifecycle.py::test_nested_buffered_child_is_finalized_and_published \
  --runxfail
```

| Case | Observed |
|---|---|
| Direct child control | PASS; `children_0.json`, `children_1.json`; ids `[1, 2, 3]` |
| Conditional child | FAIL; zero `children_*.json` files, despite the export-success log |

Expected: the true branch publishes the same two chunks and rows. Investigate the nested finalization/publication traversal in [GenerateTask](https://github.com/rapiddweller/datamimic/blob/72202ba02f99e31e737b852043e32822a2e7d4f7/datamimic_ce/engine/runtime/tasks/generate/task.py#L352); the test alone does not prove a complete root cause.

Acceptance: remove the xfail after the conditional case passes; preserve direct nesting, chunk contents and finalization-before-publication/failure cleanup. Fix in a separate behavior change with explicit compatibility evidence.

LOCAL VERIFIED: native single-process engine execution, one successful control and one conditional failure; published files inspected. CI-ONLY VERIFICATION: none for this focused probe.
No database or multiprocessing run. This fixture uses deterministic IncrementGenerator values and has no `rngSeed`. Earlier framework/temporary-directory setup errors were retained separately; neither executed a test body.
