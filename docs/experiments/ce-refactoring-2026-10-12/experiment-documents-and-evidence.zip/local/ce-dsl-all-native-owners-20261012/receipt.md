# Ordinary native XML receiver join

One batch only, exact CE HEAD384b7723d950d8b312b1080d23ffd89a5343c9b0/project.venv; native import-origin.txt confirms candidate root. Normal make test-integration test-functional, production environment, -n0, ordinary plugins plus temporary90-line observer. No Source/Test/Contract/Git edits; final git status clean.

LOCAL VERIFIED: integration573PASS2SKIP154.72s; functional133PASS52.41s. Actual make leader_exit_code0, elapsed209.26s, no timeout/leftover processes, cleanup_oktrue (terminal.json). Retained JUnit integration.xml/functional.xml and raw.log. Runner wrapper itself exit1 because it queried exit_code instead of guard's leader_exit_code; this reporting bug did not alter suite execution/status. No rerun.

Observer records only exact paths, SHA256, exception class, pytest node/phase/outcome, pid and ephemeral runtime correlation ID. Scoped wrappers preserve original arguments, results and exceptions; restored at pytest shutdown. Atomic append-only small JSONL records with O_APPEND/singlewrite, including inherited fork observers. No general IO/client patching; no descriptor values/secrets logged. Fresh independently spawned native/CLI processes without this plugin are not observed and cannot acquire execution evidence. No services were added or invoked as an additional batch; only ordinary integration/functional owners ran.

Recorded4339events,803parse records,643distinct paths:
-706direct descriptor parse invocations within RuntimeRunSession;
-78consumed includes within a session;
-19pure parses (no RuntimeRunSession execution evidence).
684parse records have returned runtime AND setup/call/teardown PASS;99runtime failed/incomplete;1returned runtime lacks complete passed test phases. These are invocation counts, not distinct profiles and not semantic PARITY/PASS. Includes establish actual consumption during returned native execution, not proof every included statement/branch ran. Parser success alone never becomes runtime evidence.

Each receiver-summary.json record retains its path/hash/node and explicit evidence category. Exact candidate paths are separate from content-equal resource candidates. Among successful-runtime/test records76distinct resource XML source paths were directly observed; no hash-only copied resource match occurred. Root must join all931 profiles against these actual path records and other existing native evidence; absent owners remain unverified. No static basename inference.

Self-controls: valid parse-only <setup/>, malformed XML and missing file, all recorded with no runtime execution. Exceptions preserved. Three controls PASS; controls.log/events.jsonl. Summary-first-failure.log retained: initial summarizer incorrectly treated every null-node parse as a self-control; fixed its selection to the three exact control paths, no suite/observer rerun. Final summary.log exit0.

Artifacts: native_owners.py, run.py, controls.py, summarize.py, events.jsonl, receiver-summary.json, terminal.json, bothJUnit, raw.log. CI-ONLY VERIFICATION: none new; prior native/external170 owners are not imported into this packet. No all931 semantic acceptance, full descriptor parity or Amendment180 promotion claim. Root/Astra own the final inventory join/classification.
