import hashlib,json
from collections import Counter
from pathlib import Path
p=Path('/private/tmp/ce-dsl-all-native-owners-20261012')
root=Path('/private/tmp/ce-literal-source-arms-candidate-20261011')
events=[json.loads(line) for line in (p/'events.jsonl').read_text().splitlines()]
phases={(e['test'],e['phase']):e['outcome'] for e in events if e['kind']=='test_phase'}
starts={e['session']:e for e in events if e['kind']=='runtime_start'}
ends={e['session']:e['outcome'] for e in events if e['kind']=='runtime_end'}
hashes={}
for source in (root/'datamimic_ce/resources').rglob('*.xml'):
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    hashes.setdefault(digest,[]).append(str(source.relative_to(root)))
records=[]
for e in events:
    if e['kind']!='parse':continue
    completed=e['session'] is not None and ends.get(e['session'])=='returned'
    node=e['node']
    test_pass=all(phases.get((node,phase))=='passed' for phase in ('setup','call','teardown'))
    runtime=e['session'] in starts
    kind='direct_descriptor' if runtime and starts[e['session']]['path']==e['path'] else 'consumed_include' if runtime else 'pure_parse'
    evidence='runtime_returned_and_test_passed' if completed and test_pass and e['outcome']=='returned' else 'runtime_returned_test_not_passed' if completed else 'runtime_failed_or_incomplete' if runtime else 'parse_only'
    path=Path(e['path'])
    exact=path.is_relative_to(root) and path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==e['sha256']
    records.append(dict(e,receiver_kind=kind,execution_evidence=evidence,exact_source_path=exact,source_relative_path=str(path.relative_to(root)) if exact else None,content_equal_resource_candidates=hashes.get(e['sha256'],[])))
controls=[r for r in records if r['path'] in {str(p/name) for name in ('parse-only.xml','invalid.xml','missing.xml')}]
assert len(controls)==3 and all(r['execution_evidence']=='parse_only' for r in controls)
assert Counter(r['outcome'] for r in controls)=={'returned':1,'failed':2}
summary={'head':json.loads((p/'terminal.json').read_text())['head'],'event_count':len(events),'parse_record_count':len(records),'receiver_counts':dict(Counter(r['receiver_kind'] for r in records)),'execution_evidence_counts':dict(Counter(r['execution_evidence'] for r in records)),'distinct_paths':len({r['path'] for r in records}),'records':records,'controls':'3PASS: parse/failedparse never execution','claim':'Receiver/runtime/test evidence only; no per-profile semantic or parity PASS'}
(p/'receiver-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
