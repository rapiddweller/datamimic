import importlib.util,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/ce-literal-source-arms-candidate-20261011')
out=pathlib.Path('/private/tmp/ce-dsl-all-native-owners-20261012')
spec=importlib.util.spec_from_file_location('guard','/private/tmp/ce-dsl-csv-mp-taskdelivery-repair-20261011/process_group_guard.py')
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
env=os.environ.copy();env.update(PATH=str(root/'.venv/bin')+':'+env['PATH'],PYTHONPATH=str(out)+':'+str(root),PYTHONDONTWRITEBYTECODE='1',RUNTIME_ENVIRONMENT='production',PYTEST_ADDOPTS='-n0 -p native_owners -p no:cacheprovider --junitxml='+str(out/'current.xml'))
started=time.monotonic()
with (out/'raw.log').open('wb') as log:
    proc=subprocess.Popen(['make','test-integration','test-functional'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    result=guard.wait_for_process_group(proc,900)
result.update(elapsed_seconds=time.monotonic()-started,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
(out/'terminal.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
raise SystemExit(result.get('returncode',result.get('exit_code',1)))
