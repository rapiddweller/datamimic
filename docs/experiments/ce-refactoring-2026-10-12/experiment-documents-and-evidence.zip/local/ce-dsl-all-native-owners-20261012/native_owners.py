import functools
import hashlib
import json
import os
import shutil
import uuid
from pathlib import Path

import pytest
from datamimic_ce.engine.dsl.parsers.document.descriptor_parser import DescriptorParser
from datamimic_ce.engine.runtime.lifecycle.runner import RuntimeRunSession

PACKET = Path('/private/tmp/ce-dsl-all-native-owners-20261012')
node = None
session = None
original_parse = DescriptorParser.parse
original_execute = RuntimeRunSession.execute


def emit(kind, **values):
    record = dict(kind=kind, pid=os.getpid(), node=node, session=session, **values)
    data = (json.dumps(record, sort_keys=True) + '\n').encode()
    fd = os.open(PACKET / 'events.jsonl', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)


@functools.wraps(original_parse)
def parse(path, *args, **kwargs):
    resolved = Path(path).resolve()
    try:
        digest = hashlib.sha256(resolved.read_bytes()).hexdigest()
    except OSError:
        digest = None
    try:
        result = original_parse(path, *args, **kwargs)
    except BaseException as error:
        emit('parse', path=str(resolved), sha256=digest, outcome='failed', error=type(error).__name__)
        raise
    emit('parse', path=str(resolved), sha256=digest, outcome='returned')
    return result


@functools.wraps(original_execute)
def execute(self, *args, **kwargs):
    global session
    previous = session
    session = str(uuid.uuid4())
    emit('runtime_start', path=str(self._request.descriptor_path.resolve()))
    try:
        result = original_execute(self, *args, **kwargs)
    except BaseException as error:
        emit('runtime_end', outcome='failed', error=type(error).__name__)
        raise
    else:
        emit('runtime_end', outcome='returned')
        return result
    finally:
        session = previous


def pytest_configure(config):
    DescriptorParser.parse = staticmethod(parse)
    RuntimeRunSession.execute = execute
    emit('observer_started')


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_protocol(item, nextitem):
    global node
    node = item.nodeid
    try:
        yield
    finally:
        node = None


def pytest_runtest_logreport(report):
    emit('test_phase', test=report.nodeid, phase=report.when, outcome=report.outcome)


def pytest_unconfigure(config):
    DescriptorParser.parse = staticmethod(original_parse)
    RuntimeRunSession.execute = original_execute
    current = PACKET / 'current.xml'
    lane = 'integration' if any('integration_tests' in arg for arg in config.args) else 'functional'
    if current.exists():
        shutil.copyfile(current, PACKET / (lane + '.xml'))
