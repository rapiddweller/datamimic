from pathlib import Path
from datamimic_ce.engine.io.api import load_connection_profile
import native_owners as observer
p=observer.PACKET
(p/'parse-only.xml').write_text('<setup/>')
(p/'invalid.xml').write_text('<setup>')
result=observer.parse(p/'parse-only.xml',None,'production',profile_loader=load_connection_profile)
assert result is not None
for name, expected in [('invalid.xml','XMLSyntaxError'),('missing.xml','FileNotFoundError')]:
    try:
        observer.parse(p/name,None,'production',profile_loader=load_connection_profile)
    except Exception as error:
        assert type(error).__name__ == expected
    else:
        raise AssertionError('failed parse unexpectedly returned')
print('3controls: parse-only success and two failed parses; no runtime execution recorded')
